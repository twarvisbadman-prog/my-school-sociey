# app.py - FULL VERSION with Cloudflare R2 + Correct Supabase Keys
import os
import uuid
import json
import re
import requests
from datetime import datetime
from django.conf import settings
from django.core.wsgi import get_wsgi_application
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django import forms
from django.urls import path
from django.views.decorators.csrf import csrf_exempt
from supabase import create_client, Client
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
import hub_db

# ============================================================
# LOAD .env FOR LOCAL DEVELOPMENT
# ============================================================
try:
    from dotenv import load_dotenv
    from pathlib import Path
    env_path = Path(__file__).parent / '.env'
    if env_path.exists():
        load_dotenv(env_path)
        print("✅ Loaded .env file")
except ImportError:
    pass  # python-dotenv not installed — use system env vars

# ============================================================
# SAFE ENV VAR LOADER
# ============================================================
def env(key, default=""):
    """Get env var, strip whitespace, fall back to default if empty or placeholder."""
    val = os.environ.get(key, "").strip()
    placeholders = [
        "https://your-project.supabase.co",
        "your_anon_key_here",
        "your_service_key_here",
        "your_secret_key_here_at_least_32_chars"
    ]
    if val in placeholders:
        return default
    return val if val else default


# ============================================================
# CONFIGURATION — CORRECT KEYS
# ============================================================

# ---------- Django ----------
SECRET_KEY = env("SECRET_KEY", "django-insecure-twarvis-school-key-2024")
DEBUG = env("DEBUG", "False").lower() == "true"

# ---------- Supabase ----------
SUPABASE_URL = env(
    "SUPABASE_URL",
    "https://hnszltswipxiqurkwydm.supabase.co"
)
SUPABASE_KEY = env(
    "SUPABASE_KEY",
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhuc3psdHN3aXB4aXF1cmt3eWRtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzc1NTEyODcsImV4cCI6MjA5MzEyNzI4N30.JsSgMXE9JMqJAAZd-riwrr-D-5MURL6WCfuNTrAtoWU"
)

# ---------- Cloudflare R2 ----------
R2_ACCESS_KEY_ID = env("R2_ACCESS_KEY_ID", "5b7111f929b3cd22162e7a20ef69a09a")
R2_SECRET_ACCESS_KEY = env("R2_SECRET_ACCESS_KEY", "0cebef92f4316520d5553049763e957eb7f3f778e51cd57eeaa9b797a013d6c7")
R2_BUCKET_NAME = env("R2_BUCKET_NAME", "pdf")
R2_ENDPOINT_URL = env("R2_ENDPOINT_URL", "https://29d150504a083e2cf780e2115ebc9b28.r2.cloudflarestorage.com")
R2_PUBLIC_URL = env("R2_PUBLIC_URL", "https://pub-062ab58e23db4e31a628e6f6273a014c.r2.dev").rstrip("/")

# ---------- Admin ----------
SECRET_ADMIN_PATH = env("SECRET_ADMIN_PATH", "admin-portal-twarvis-9x7k2m4p8q3z5w6v")
ADMIN = True

# ---------- Hosts ----------
_allowed = env("ALLOWED_HOSTS", "*")
ALLOWED_HOSTS = [h.strip() for h in _allowed.split(",") if h.strip()]
if "testserver" not in ALLOWED_HOSTS and "*" not in ALLOWED_HOSTS:
    ALLOWED_HOSTS.append("testserver")

_csrf = env("CSRF_TRUSTED_ORIGINS", "https://*.onrender.com,https://*.vercel.app,http://localhost:8000")
CSRF_TRUSTED_ORIGINS = [o.strip() for o in _csrf.split(",") if o.strip()]

# ============================================================
# CONFIG SANITY CHECK
# ============================================================
print("=" * 60)
print("🚀 TWARVIS SCHOOL — R2 + ENV VERSION")
print("=" * 60)
print(f"📡 Supabase URL:  {SUPABASE_URL[:50]}")
print(f"🔑 Supabase Key:  {'✅ VALID JWT' if SUPABASE_KEY.startswith('eyJ') else '❌ INVALID'}")
print(f"☁️  R2 Bucket:    {R2_BUCKET_NAME}")
print(f"☁️  R2 Endpoint:  {R2_ENDPOINT_URL[:50]}")
print(f"☁️  R2 Public:    {R2_PUBLIC_URL[:50]}")
print(f"🔐 Admin URL:     /{SECRET_ADMIN_PATH}/")
print(f"🐛 Debug:         {DEBUG}")
print("=" * 60)

# Verify Supabase key format
if not SUPABASE_KEY.startswith("eyJ"):
    print("❌ FATAL: SUPABASE_KEY is invalid!")
    print(f"   Got: {SUPABASE_KEY[:40]}...")
    print("   Expected: a JWT starting with 'eyJ'")
    raise SystemExit(1)

print("✅ Supabase key format is valid (starts with 'eyJ')")

# ============================================================
# CONTEXT PROCESSOR FOR STUDENT SESSIONS & SOCIAL TOKENS
# ============================================================
def student_context_processor(request):
    username = ""
    try:
        if hasattr(request, "session"):
            username = request.session.get("username", "")
    except Exception:
        pass
    student = hub_db.get_student_by_username(username) if username else None
    return {
        "current_student": student,
        "is_authenticated": bool(student),
        "app_tokens": hub_db.TOKENS_CATALOG,
        "all_universities": UNIVERSITIES,
    }

# ============================================================
# DJANGO SETTINGS
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

if not settings.configured:
    settings.configure(
        DEBUG=DEBUG,
        SECRET_KEY=SECRET_KEY,
        ROOT_URLCONF=__name__,
        ALLOWED_HOSTS=ALLOWED_HOSTS,
        INSTALLED_APPS=[
            "django.contrib.staticfiles",
            "django.contrib.sessions",
        ],
        MIDDLEWARE=[
            "django.middleware.common.CommonMiddleware",
            "django.contrib.sessions.middleware.SessionMiddleware",
            "django.middleware.csrf.CsrfViewMiddleware",
            "django.middleware.clickjacking.XFrameOptionsMiddleware",
        ],
        SESSION_ENGINE="django.contrib.sessions.backends.signed_cookies",
        SESSION_COOKIE_NAME="hub_sessionid",
        SESSION_COOKIE_AGE=86400 * 30,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        TEMPLATES=[{
            "BACKEND": "django.template.backends.django.DjangoTemplates",
            "DIRS": [BASE_DIR],
            "APP_DIRS": False,
            "OPTIONS": {
                "context_processors": [
                    "django.template.context_processors.debug",
                    "django.template.context_processors.request",
                    "app.student_context_processor",
                ],
            },
        }],
        STATIC_URL="/static/",
        STATICFILES_DIRS=[BASE_DIR],
        CSRF_TRUSTED_ORIGINS=CSRF_TRUSTED_ORIGINS,
        X_FRAME_OPTIONS="SAMEORIGIN",
        USE_TZ=True,
        TIME_ZONE="Africa/Dar_es_Salaam",
    )

from django import forms


# ============================================================
# SUPABASE CLIENT
# ============================================================
try:
    supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
    print("✅ Supabase connected!")
except Exception as e:
    print(f"❌ Supabase connection FAILED: {e}")
    raise SystemExit(1)

# ============================================================
# CLOUDFLARE R2 CLIENT
# ============================================================
r2_client = None
try:
    if R2_ACCESS_KEY_ID and R2_SECRET_ACCESS_KEY and R2_ENDPOINT_URL:
        r2_client = boto3.client(
            "s3",
            endpoint_url=R2_ENDPOINT_URL,
            aws_access_key_id=R2_ACCESS_KEY_ID,
            aws_secret_access_key=R2_SECRET_ACCESS_KEY,
            config=Config(signature_version="s3v4"),
            region_name="auto",
        )
        print("✅ Cloudflare R2 client initialized!")
    else:
        print("⚠️  R2 credentials missing — uploads will fail")
except Exception as e:
    print(f"⚠️  R2 client init failed: {e}")
    r2_client = None

# ============================================================
# CONSTANTS
# ============================================================
ALLOWED_EXTENSIONS = [
    '.pdf', '.ppt', '.pptx', '.doc', '.docx', '.txt', '.md',
    '.xls', '.xlsx', '.csv', '.jpg', '.jpeg', '.png', '.gif',
    '.zip', '.rar'
]

UNIVERSITIES = [
    "University of Dar es Salaam (UDSM)",
    "Sokoine University of Agriculture (SUA)",
    "Muhimbili University of Health and Allied Sciences (MUHAS)",
    "University of Dodoma (UDOM)",
    "Mzumbe University",
    "State University of Zanzibar (SUZA)",
    "Nelson Mandela African Institute of Science and Technology (NM-AIST)",
    "Ardhi University (ARU)",
    "Dar es Salaam Institute of Technology (DIT)",
    "College of Business Education (CBE)",
    "Institute of Finance Management (IFM)",
    "Tumaini University Makumira",
    "St. Augustine University of Tanzania (SAUT)",
    "Ruaha Catholic University (RUCU)",
    "Jordan University College (JUCO)",
    "Kampala International University (KIU) - Tanzania Campus",
    "Mount Meru University (MMU)",
    "Teofilo Kisanji University (TEKU)",
    "St. John's University of Tanzania (SJUT)",
    "Zanzibar University (ZU)",
    "University of Bagamoyo",
    "Kibabii University Tanzania Campus",
    "East and Southern African Management Institute (ESAMI)",
    "Moshi Co-operative University (MoCU)",
    "Tanzania Institute of Accountancy (TIA)",
    "National Institute of Transport (NIT)",
    "Tanzania Petroleum Institute (TPI)",
    "Mwalimu Nyerere Memorial Academy (MNMA)",
    "Dodoma University of Science and Technology",
    "Arusha Technical College (ATC)",
    "Karagwe Technical College",
    "Mbeya University of Science and Technology (MUST)",
    "Rukwa Technical College", "Tanga Technical College",
    "Kigoma Technical College", "Lindi Technical College",
    "Mtwara Technical College", "Tabora Technical College",
    "Iringa Technical College", "Morogoro Technical College",
    "Mwanza Technical College", "Kilimanjaro Technical College",
    "Singida Technical College", "Shinyanga Technical College",
    "Katavi Technical College", "Njombe Technical College",
    "Geita Technical College", "Simiyu Technical College",
    "Songwe Technical College", "Manyara Technical College",
]

# ============================================================
# FORMS
# ============================================================
class UploadForm(forms.Form):
    file = forms.FileField(label="File", widget=forms.FileInput(attrs={"class": "form-file", "required": True}))
    file_type = forms.ChoiceField(choices=[('notes', 'Notes'), ('pastpaper', 'Past Paper')], widget=forms.RadioSelect, initial='notes')
    module = forms.CharField(max_length=200, label="Module Name", widget=forms.TextInput(attrs={"class": "form-input", "placeholder": "e.g., Computer Networks..."}))
    course = forms.CharField(max_length=200, label="Course Code", widget=forms.TextInput(attrs={"class": "form-input", "placeholder": "e.g., CIT 3102..."}))
    description = forms.CharField(widget=forms.Textarea(attrs={"class": "form-textarea", "rows": 3, "placeholder": "Brief description..."}), label="Description", required=False)
    privacy = forms.ChoiceField(choices=[('public', 'Public'), ('private', 'Private')], widget=forms.RadioSelect, initial='public')
    passcode = forms.CharField(max_length=4, required=False, widget=forms.PasswordInput(attrs={"class": "passcode-input", "placeholder": "••••", "maxlength": "4"}))
    university = forms.ChoiceField(choices=[('', '-- Select your university --')] + [(u, u) for u in UNIVERSITIES] + [('Other', 'Other')], required=False, widget=forms.Select(attrs={"class": "form-select"}))
    custom_university = forms.CharField(max_length=200, required=False, widget=forms.TextInput(attrs={"class": "form-input", "placeholder": "Type your university name..."}))


class EditForm(forms.Form):
    module = forms.CharField(max_length=200, required=True,
                             widget=forms.TextInput(attrs={"class": "form-input", "placeholder": "e.g., Computer Networks"}))
    course = forms.CharField(max_length=200, required=True,
                             widget=forms.TextInput(attrs={"class": "form-input", "placeholder": "e.g., CIT 3102"}))
    description = forms.CharField(required=False,
                                  widget=forms.Textarea(attrs={"class": "form-textarea", "rows": 4, "placeholder": "Brief description..."}))
    university = forms.CharField(max_length=200, required=False,
                                 widget=forms.TextInput(attrs={"class": "form-input", "placeholder": "e.g., UDSM"}))
    file_type = forms.ChoiceField(
        choices=[('notes', 'Notes'), ('pastpaper', 'Past Paper')],
        widget=forms.Select(attrs={"class": "form-select"})
    )

# ============================================================
# R2 HELPER FUNCTIONS
# ============================================================
def upload_to_r2(file_obj, key, content_type="application/octet-stream"):
    """Upload a file to Cloudflare R2. Returns public URL or None."""
    if not r2_client:
        print("❌ R2 client not initialized")
        return None
    try:
        file_obj.seek(0)
        r2_client.upload_fileobj(
            file_obj,
            R2_BUCKET_NAME,
            key,
            ExtraArgs={
                "ContentType": content_type,
                "CacheControl": "max-age=86400",
            },
        )
        url = f"{R2_PUBLIC_URL}/{key}"
        print(f"✅ Uploaded to R2: {url}")
        return url
    except ClientError as e:
        print(f"❌ R2 upload failed: {e}")
        return None
    except Exception as e:
        print(f"❌ R2 upload exception: {e}")
        return None


def delete_from_r2(key):
    """Delete a file from R2 by its key."""
    if not r2_client:
        return False
    try:
        r2_client.delete_object(Bucket=R2_BUCKET_NAME, Key=key)
        print(f"✅ Deleted from R2: {key}")
        return True
    except ClientError as e:
        print(f"❌ R2 delete failed: {e}")
        return False


def get_r2_public_url(key):
    """Build the public URL for an R2 object."""
    return f"{R2_PUBLIC_URL}/{key}"


def get_r2_file_bytes(key):
    """Download a file from R2 and return bytes, or None."""
    if not r2_client:
        return None
    try:
        response = r2_client.get_object(Bucket=R2_BUCKET_NAME, Key=key)
        return response["Body"].read()
    except ClientError as e:
        print(f"❌ R2 download failed: {e}")
        return None

# ============================================================
# HELPER FUNCTIONS
# ============================================================
def get_content_type(filename):
    ext = os.path.splitext(filename)[1].lower()
    types = {
        '.pdf': 'application/pdf',
        '.ppt': 'application/vnd.ms-powerpoint',
        '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        '.doc': 'application/msword',
        '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        '.txt': 'text/plain',
        '.md': 'text/markdown',
        '.xls': 'application/vnd.ms-excel',
        '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        '.csv': 'text/csv',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png': 'image/png',
        '.gif': 'image/gif',
    }
    return types.get(ext, 'application/octet-stream')

def get_file_icon(filename):
    ext = os.path.splitext(filename)[1].lower()
    icons = {
        '.pdf': '📄', '.ppt': '📊', '.pptx': '📊', '.doc': '📝', '.docx': '📝',
        '.xls': '📈', '.xlsx': '📈', '.txt': '📃', '.md': '📃', '.jpg': '🖼️',
        '.jpeg': '🖼️', '.png': '🖼️', '.gif': '🖼️', '.zip': '📦', '.rar': '📦',
    }
    return icons.get(ext, '📁')

def can_view_inline(filename):
    ext = os.path.splitext(filename)[1].lower()
    viewable = ['.pdf', '.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg', '.txt', '.md', '.csv']
    return ext in viewable

def get_all_notes():
    try:
        response = supabase.table("notes").select("*").order("uploaded_at", desc=True).execute()
        notes = response.data if response.data else []
        for note in notes:
            note["original_filename"] = note.get("original_filename", note.get("filename", ""))
            note["file_size"] = note.get("file_size", 0)
            note["privacy"] = note.get("privacy", "public")
            note["file_type"] = note.get("file_type", "notes")
            note["university"] = note.get("university", "Not specified")
            note["passcode"] = note.get("passcode", "")
            note["can_view_inline"] = can_view_inline(note.get("filename", ""))
        return notes
    except Exception as e:
        print(f"Error: {e}")
        return []

def search_notes(query):
    try:
        response = supabase.table("notes").select("*").or_(f"module.ilike.%{query}%,course.ilike.%{query}%,description.ilike.%{query}%").order("uploaded_at", desc=True).execute()
        return response.data if response.data else []
    except Exception as e:
        return get_all_notes()

# ============================================================
# PASSCODE HTML
# ============================================================
def get_passcode_html(file_id, filename, error=None):
    error_html = f'<div class="error-msg" style="color:#ff4444;font-size:0.85rem;margin-top:12px;background:rgba(255,68,68,0.05);padding:10px;border-radius:10px;border:1px solid rgba(255,68,68,0.1);">{error}</div>' if error else '<div class="error-msg" id="passcodeError" style="color:#ff4444;font-size:0.85rem;margin-top:12px;display:none;background:rgba(255,68,68,0.05);padding:10px;border-radius:10px;border:1px solid rgba(255,68,68,0.1);">❌ Incorrect passcode. Please try again.</div>'

    return f'''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Passcode Required | Student Hub</title>
    <link rel="icon" type="image/png" href="/apple-touch-icon.png">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400;14..32,500;14..32,600;14..32,700;14..32,800;14..32,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * {{ margin:0; padding:0; box-sizing:border-box; }}
        body {{ font-family:'Inter',sans-serif; background:#fafaf9; min-height:100vh; display:flex; align-items:center; justify-content:center; overflow-x:hidden; padding:20px; }}
        .container {{ position:relative; z-index:2; max-width:450px; width:100%; }}
        .card {{ background:#ffffff; border:1px solid #e7e5e4; border-radius:28px; padding:40px 35px; box-shadow:0 28px 64px -20px rgba(28,25,23,.22); text-align:center; }}
        .card .lock-icon {{ display:inline-flex; align-items:center; justify-content:center; width:82px; height:82px; margin-bottom:18px; border-radius:50%; background:#fef3c7; color:#b45309; font-size:2rem; }}
        .card h1 {{ font-size:1.6rem; font-weight:800; color:#1c1917; margin-bottom:8px; }}
        .card .sub-text {{ color:#57534e; font-size:0.88rem; margin-bottom:16px; }}
        .card .filename {{ color:#44403c; font-size:0.85rem; margin-bottom:20px; padding:12px; background:#f5f5f4; border-radius:12px; border:1px solid #e7e5e4; word-break:break-all; }}
        .card .passcode-hint {{ color:#78716c; font-size:0.72rem; margin-bottom:12px; }}
        .card input {{ width:100%; padding:16px 18px; background:#fafaf9; border:1px solid #e7e5e4; border-radius:16px; color:#1c1917; font-size:1.4rem; font-family:'Courier New',monospace; letter-spacing:12px; text-align:center; transition:0.25s; outline:none; }}
        .card input:focus {{ border-color:#ea580c; background:#ffffff; box-shadow:0 0 0 4px rgba(234,88,12,.12); }}
        {error_html}
        .card button {{ width:100%; padding:15px; margin-top:16px; background:linear-gradient(120deg,#c2410c,#be185d); border:none; border-radius:999px; color:#fff; font-weight:800; font-size:1rem; cursor:pointer; transition:0.25s; box-shadow:0 8px 22px -8px rgba(219,39,119,.5); }}
        .card button:hover {{ transform:translateY(-2px); box-shadow:0 12px 28px -8px rgba(219,39,119,.6); }}
        .back-link {{ display:inline-block; margin-top:16px; color:#57534e; text-decoration:none; font-size:0.85rem; }}
        .back-link:hover {{ color:#c2410c; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <span class="lock-icon"><i class="fas fa-lock"></i></span>
            <h1>🔒 Private Document</h1>
            <p class="sub-text">Enter the passcode to view this document</p>
            <div class="filename"><i class="fas fa-file"></i> {filename}</div>
            <p class="passcode-hint">Enter the 4-digit passcode set by the uploader</p>
            <input type="password" id="passcodeInput" placeholder="••••" maxlength="4" inputmode="numeric" autofocus>
            {error_html}
            <button id="unlockBtn"><i class="fas fa-unlock"></i> Unlock Document</button>
            <div style="margin-top:12px;">
                <a href="/browse/" class="back-link"><i class="fas fa-arrow-left"></i> Back to Browse</a>
            </div>
        </div>
    </div>
    <script>
        const input = document.getElementById('passcodeInput');
        const btn = document.getElementById('unlockBtn');
        const error = document.getElementById('passcodeError');
        const fileId = {file_id};
        if (error) {{ error.style.display = 'none'; }}
        input.addEventListener('input', function() {{
            this.value = this.value.replace(/\\D/g, '').slice(0, 4);
            if (error) {{ error.classList.remove('show'); error.style.display = 'none'; }}
        }});
        btn.addEventListener('click', function() {{
            const passcode = input.value.trim();
            if (passcode.length === 4) {{
                window.location.href = `/view/{file_id}/?passcode=${{passcode}}`;
            }} else {{
                if (error) {{ error.textContent = '❌ Please enter a 4-digit passcode'; error.classList.add('show'); error.style.display = 'block'; }}
                input.value = ''; input.focus();
            }}
        }});
        input.addEventListener('keydown', function(e) {{ if (e.key === 'Enter') btn.click(); }});
        input.focus();
    </script>
</body>
</html>
'''

# ============================================================
# SERVE ROOT FILES
# ============================================================
def serve_root_file(request, filename):
    safe_name = os.path.basename(filename)
    if safe_name != filename or ".." in safe_name or safe_name.startswith("."):
        return HttpResponse("Not found", status=404)

    file_path = os.path.join(BASE_DIR, safe_name)
    if not os.path.exists(file_path):
        return HttpResponse("Not found", status=404)

    ext = os.path.splitext(safe_name)[1].lower()
    content_types = {
        ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".gif": "image/gif", ".svg": "image/svg+xml", ".webp": "image/webp",
        ".ico": "image/x-icon", ".css": "text/css", ".js": "application/javascript",
        ".json": "application/json", ".txt": "text/plain", ".xml": "application/xml",
        ".pdf": "application/pdf", ".woff": "font/woff", ".woff2": "font/woff2",
    }
    content_type = content_types.get(ext, "application/octet-stream")

    try:
        with open(file_path, "rb") as f:
            data = f.read()
        response = HttpResponse(data, content_type=content_type)
        response["Cache-Control"] = "public, max-age=2592000"
        return response
    except Exception as e:
        print(f"Error serving {safe_name}: {e}")
        return HttpResponse("Error", status=500)


# ============================================================
# SERVE FILES FROM SUBFOLDERS
# ============================================================
def serve_subfolder_file(request, subpath):
    """
    Safely serve any file from within BASE_DIR subfolders.
    Used for free_course/<course>/index.html and assets.
    """
    safe_subpath = os.path.normpath(subpath).replace("\\", "/")
    if safe_subpath.startswith("..") or safe_subpath.startswith("/") or ".." in safe_subpath.split("/"):
        return HttpResponse("Not found", status=404)

    file_path = os.path.join(BASE_DIR, safe_subpath)
    real_path = os.path.realpath(file_path)
    real_base = os.path.realpath(BASE_DIR)

    if not real_path.startswith(real_base):
        return HttpResponse("Not found", status=404)

    if not os.path.exists(real_path) or os.path.isdir(real_path):
        return HttpResponse("Not found", status=404)

    ext = os.path.splitext(real_path)[1].lower()
    content_types = {
        ".html": "text/html; charset=utf-8",
        ".htm": "text/html; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".js": "application/javascript; charset=utf-8",
        ".mjs": "application/javascript; charset=utf-8",
        ".json": "application/json",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".svg": "image/svg+xml",
        ".webp": "image/webp",
        ".ico": "image/x-icon",
        ".woff": "font/woff",
        ".woff2": "font/woff2",
        ".ttf": "font/ttf",
        ".otf": "font/otf",
        ".pdf": "application/pdf",
        ".txt": "text/plain; charset=utf-8",
        ".md": "text/markdown; charset=utf-8",
        ".xml": "application/xml",
        ".map": "application/json",
        ".mp4": "video/mp4",
        ".webm": "video/webm",
        ".mp3": "audio/mpeg",
        ".wav": "audio/wav",
    }
    content_type = content_types.get(ext, "application/octet-stream")

    try:
        with open(real_path, "rb") as f:
            data = f.read()

        response = HttpResponse(data, content_type=content_type)

        if ext in (".html", ".htm"):
            response["Cache-Control"] = "public, max-age=300"
        else:
            response["Cache-Control"] = "public, max-age=2592000"

        return response
    except Exception as e:
        print(f"Error serving {safe_subpath}: {e}")
        return HttpResponse("Error", status=500)


def serve_static_file(request, subpath):
    """Serve static assets from static/ directory with appropriate mime types and caching."""
    return serve_subfolder_file(request, f"static/{subpath}")


# ============================================================
# FAVICON
# ============================================================
def favicon_view(request):
    icon_path = os.path.join(BASE_DIR, "apple-touch-icon.png")
    if os.path.exists(icon_path):
        try:
            with open(icon_path, "rb") as f:
                data = f.read()
            response = HttpResponse(data, content_type="image/png")
            response["Cache-Control"] = "public, max-age=2592000"
            return response
        except Exception as e:
            print(f"Favicon error: {e}")
    return HttpResponse(status=204)


# ============================================================
# VIEWS
# ============================================================
def index(request):
    top_leaders = hub_db.get_leaderboard("streak", 3)
    tokens_preview = hub_db.TOKENS_CATALOG[:6]
    return render(request, "index.html", {
        "top_leaders": top_leaders,
        "tokens_preview": tokens_preview
    })

def upload_view(request):
    message = None
    error = None

    if request.method == "POST":
        form = UploadForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                file = request.FILES["file"]
                ext = os.path.splitext(file.name)[1].lower()

                if ext not in ALLOWED_EXTENSIONS:
                    error = f"File type not allowed."
                else:
                    file_type = form.cleaned_data.get("file_type", "notes")
                    module = form.cleaned_data.get("module", "")
                    course = form.cleaned_data.get("course", "")
                    description = form.cleaned_data.get("description", "")
                    privacy = form.cleaned_data.get("privacy", "public")
                    passcode = form.cleaned_data.get("passcode", "")

                    university = form.cleaned_data.get("university", "")
                    if university == "Other":
                        university = form.cleaned_data.get("custom_university", "")
                    if not university:
                        university = "Not specified"

                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    unique_id = str(uuid.uuid4())[:8]
                    safe_filename = f"{timestamp}_{unique_id}_{file.name.replace(' ', '_')}"

                    file_content = file.read()
                    file_size = len(file_content)

                    r2_key = f"notes/{safe_filename}"
                    content_type = file.content_type or get_content_type(file.name)

                    file.seek(0)
                    r2_url = upload_to_r2(file, r2_key, content_type=content_type)

                    if not r2_url:
                        error = "Upload to storage failed. Please try again."
                        print(f"❌ R2 upload failed for {safe_filename}")
                    else:
                        uploader_name = request.session.get("username", "user")
                        new_id = None
                        try:
                            ins_res = supabase.table("notes").insert({
                                "filename": safe_filename,
                                "original_filename": file.name,
                                "module": module,
                                "course": course,
                                "description": description,
                                "file_type": file_type,
                                "privacy": privacy,
                                "passcode": passcode if privacy == "private" else "",
                                "university": university,
                                "uploader": uploader_name,
                                "uploaded_at": datetime.now().isoformat(),
                                "file_size": file_size
                            }).execute()
                            if ins_res.data and len(ins_res.data) > 0:
                                new_id = ins_res.data[0].get("id")
                        except Exception as sup_err:
                            print(f"Supabase record notice: {sup_err}")

                        # Store in hub_db for persistent personal upload history
                        hub_db.record_upload_history(
                            username=uploader_name,
                            filename=safe_filename,
                            original_filename=file.name,
                            module=module,
                            course=course,
                            university=university,
                            file_size=file_size,
                            privacy=privacy,
                            passcode=passcode,
                            file_type=file_type,
                            file_id=new_id
                        )

                        message = f"✅ {file.name} uploaded successfully!"
                        form = UploadForm()

            except Exception as e:
                error = f"Upload failed: {str(e)}"
                print(f"❌ ERROR: {error}")
        else:
            error = "Please fill all required fields."
    else:
        form = UploadForm()

    return render(request, "upload.html", {"form": form, "message": message, "error": error})

def browse_view(request):
    query = request.GET.get("q", "").strip()
    notes = search_notes(query) if query else get_all_notes()
    username = request.session.get("username", "")

    for note in notes:
        ext = os.path.splitext(note.get("filename", ""))[1].upper().replace(".", "")
        note["file_ext"] = ext if ext else "FILE"
        note["icon"] = get_file_icon(note.get("filename", ""))

        if note.get("module") and note.get("module") != "":
            note["display_name"] = note.get("module")
        else:
            original = note.get("original_filename", note.get("filename", ""))
            cleaned = re.sub(r'^\d{8}_\d{6}_', '', original)
            note["display_name"] = cleaned[:50] + "..." if len(cleaned) > 50 else cleaned

        note["can_view_inline"] = can_view_inline(note.get("filename", ""))
        note["is_private"] = note.get("privacy", "public") == "private"
        note["has_passcode"] = bool(note.get("passcode", ""))
        note["is_fav"] = hub_db.is_favorite(username, note.get("id"), "note") if username else False

        if not note.get("university"):
            note["university"] = "Not specified"
        if not note.get("file_type"):
            note["file_type"] = "notes"
        if not note.get("module"):
            note["module"] = "Untitled"
        if not note.get("course"):
            note["course"] = "N/A"

    return render(request, "browse.html", {"notes": notes, "query": query})

def view_file(request, id):
    try:
        result = supabase.table("notes").select("*").eq("id", id).execute()

        if not result.data:
            return HttpResponse("File not found", status=404)

        note = result.data[0]

        if note.get("privacy") == "private":
            correct_passcode = note.get("passcode", "")
            get_passcode = request.GET.get("passcode", "")

            if not get_passcode:
                html = get_passcode_html(id, note.get("original_filename", note.get("filename", "")))
                return HttpResponse(html)

            if get_passcode != correct_passcode:
                html = get_passcode_html(id, note.get("original_filename", note.get("filename", "")), "❌ Incorrect passcode. Please try again.")
                return HttpResponse(html)

        r2_key = f"notes/{note['filename']}"
        file_url = get_r2_public_url(r2_key)

        note["can_view_inline"] = can_view_inline(note.get("filename", ""))
        note["is_pdf"] = os.path.splitext(note.get("filename", ""))[1].lower() == '.pdf'
        note["is_image"] = os.path.splitext(note.get("filename", ""))[1].lower() in ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg']
        note["is_text"] = os.path.splitext(note.get("filename", ""))[1].lower() in ['.txt', '.md', '.csv', '.json', '.xml']

        note["text_content"] = ""
        if note["is_text"] and file_url:
            try:
                response = requests.get(file_url, timeout=10)
                if response.status_code == 200:
                    note["text_content"] = response.text
            except:
                pass

        username = request.session.get("username", "")
        is_fav = hub_db.is_favorite(username, id, "note") if username else False
        uploader_user = note.get("uploader")
        uploader_student = hub_db.get_student_by_username(uploader_user) if (uploader_user and uploader_user != "user") else None
        is_following_uploader = hub_db.is_following(username, uploader_student["username"]) if (username and uploader_student) else False

        context = {
            "note": note,
            "pdf_url": file_url,
            "admin": ADMIN,
            "is_fav": is_fav,
            "uploader_student": uploader_student,
            "is_following_uploader": is_following_uploader
        }

        return render(request, "view.html", context)

    except Exception as e:
        return HttpResponse(f"Error: {str(e)}", status=500)


def download_file(request, id):
    try:
        result = supabase.table("notes").select("*").eq("id", id).execute()

        if not result.data:
            return HttpResponse("File not found", status=404)

        note = result.data[0]

        if note.get("privacy") == "private":
            correct_passcode = note.get("passcode", "")
            get_passcode = request.GET.get("passcode", "")

            if not get_passcode:
                return HttpResponse("Access Denied. This file is private. Please view it first to unlock.", status=403)

            if get_passcode != correct_passcode:
                return HttpResponse("Access Denied. Incorrect passcode.", status=403)

        r2_key = f"notes/{note['filename']}"
        file_data = get_r2_file_bytes(r2_key)

        if file_data is None:
            return HttpResponse("File not found in storage", status=404)

        content_type = get_content_type(note["filename"])
        response = HttpResponse(file_data, content_type=content_type)
        response["Content-Disposition"] = f"attachment; filename=\"{note.get('original_filename', note['filename'])}\""
        return response
    except Exception as e:
        return HttpResponse(f"Download failed: {str(e)}", status=500)

def delete_file(request, id):
    if not ADMIN:
        return HttpResponse("Not authorized.", status=403)
    try:
        note = supabase.table("notes").select("*").eq("id", id).execute().data[0]

        delete_from_r2(f"notes/{note['filename']}")

        supabase.table("notes").delete().eq("id", id).execute()

        return redirect(f"/{SECRET_ADMIN_PATH}/")
    except Exception as e:
        return HttpResponse(f"Delete failed: {str(e)}", status=500)

def favicon(request):
    return HttpResponse(status=204)

@csrf_exempt
def update_passcode(request, id):
    if not ADMIN:
        return JsonResponse({"success": False, "error": "Not authorized"}, status=403)

    if request.method != "POST":
        return JsonResponse({"success": False, "error": "Method not allowed"}, status=405)

    try:
        data = json.loads(request.body)
        new_passcode = data.get("passcode", "").strip()

        if not new_passcode:
            return JsonResponse({"success": False, "error": "Passcode is required"})

        if not new_passcode.isdigit():
            return JsonResponse({"success": False, "error": "Passcode must contain only numbers"})

        if len(new_passcode) != 4:
            return JsonResponse({"success": False, "error": "Passcode must be exactly 4 digits"})

        check_result = supabase.table("notes").select("*").eq("id", id).execute()
        if not check_result.data:
            return JsonResponse({"success": False, "error": "File not found"})

        note = check_result.data[0]
        if note.get("privacy") != "private":
            return JsonResponse({"success": False, "error": "File is not private"})

        supabase.table("notes").update({"passcode": new_passcode}).eq("id", id).execute()

        return JsonResponse({"success": True, "message": "Passcode updated successfully"})

    except json.JSONDecodeError:
        return JsonResponse({"success": False, "error": "Invalid JSON data"}, status=400)
    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)}, status=500)


@csrf_exempt
def update_metadata(request, id):
    """Admin — update module, course, description, university, file_type."""
    if not ADMIN:
        return JsonResponse({"success": False, "error": "Not authorized"}, status=403)

    if request.method != "POST":
        return JsonResponse({"success": False, "error": "Method not allowed"}, status=405)

    try:
        data = json.loads(request.body)

        check_result = supabase.table("notes").select("*").eq("id", id).execute()
        if not check_result.data:
            return JsonResponse({"success": False, "error": "File not found"})

        allowed_fields = ["module", "course", "description", "university", "file_type"]
        update_data = {}
        for field in allowed_fields:
            if field in data:
                value = str(data[field]).strip()
                update_data[field] = value

        if not update_data:
            return JsonResponse({"success": False, "error": "No valid fields to update"})

        if "file_type" in update_data and update_data["file_type"] not in ["notes", "pastpaper"]:
            return JsonResponse({"success": False, "error": "Invalid file_type"})

        supabase.table("notes").update(update_data).eq("id", id).execute()

        return JsonResponse({"success": True, "message": "Metadata updated", "updated": update_data})

    except json.JSONDecodeError:
        return JsonResponse({"success": False, "error": "Invalid JSON"}, status=400)
    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)}, status=500)


def admin_edit(request, id):
    """Admin — edit note metadata with a full page form."""
    if not ADMIN:
        return HttpResponse("Access Denied. Admin only.", status=403)

    try:
        result = supabase.table("notes").select("*").eq("id", id).execute()
        if not result.data:
            return HttpResponse("File not found", status=404)

        note = result.data[0]
        error_message = None

        if request.method == "POST":
            module = request.POST.get("module", "").strip()
            course = request.POST.get("course", "").strip()
            description = request.POST.get("description", "").strip()
            university = request.POST.get("university", "").strip()
            file_type = request.POST.get("file_type", "notes").strip()

            if not module or not course:
                error_message = "Module and Course are required."
            else:
                supabase.table("notes").update({
                    "module": module,
                    "course": course,
                    "description": description,
                    "university": university or "Not specified",
                    "file_type": file_type,
                }).eq("id", id).execute()

                return redirect(f"/{SECRET_ADMIN_PATH}/")

        form = EditForm(initial={
            "module": note.get("module", ""),
            "course": note.get("course", ""),
            "description": note.get("description", ""),
            "university": note.get("university", ""),
            "file_type": note.get("file_type", "notes"),
        })

        return render(request, "admin_edit.html", {
            "note": note,
            "form": form,
            "error": error_message,
        })

    except Exception as e:
        return HttpResponse(f"Error: {str(e)}", status=500)


def admin_dashboard(request):
    if not ADMIN:
        return HttpResponse("Access Denied. Admin only.", status=403)

    all_notes = get_all_notes()
    total_files = len(all_notes)
    file_types = {}
    modules = {}
    total_size = 0
    private_count = 0
    public_count = 0

    for note in all_notes:
        ext = os.path.splitext(note.get("filename", ""))[1].upper()
        if ext:
            file_types[ext] = file_types.get(ext, 0) + 1
        module = note.get("module", "Unknown")
        modules[module] = modules.get(module, 0) + 1
        total_size += note.get("file_size", 0)

        if note.get("privacy") == "private":
            private_count += 1
        else:
            public_count += 1

    stats = {
        "total_files": total_files,
        "file_types": file_types,
        "top_modules": dict(sorted(modules.items(), key=lambda x: x[1], reverse=True)[:5]),
        "total_size_mb": round(total_size / (1024 * 1024), 2),
        "private_count": private_count,
        "public_count": public_count
    }

    return render(request, "admin.html", {"notes": all_notes, "stats": stats, "admin": ADMIN})

def admin_settings(request):
    if not ADMIN:
        return HttpResponse("Access Denied. Admin only.", status=403)
    return render(request, "admin_settings.html", {})


# ========== ABOUT VIEW ==========
def about_view(request):
    try:
        return render(request, "about.html")
    except Exception as e:
        return HttpResponse(f"About page error: {e}", status=500)


# ========== CALCULATOR VIEW ==========
def calculator_view(request):
    return render(request, "calculator.html")


# ========== HACKATHON VIEW ==========
def hackathon_view(request):
    try:
        return render(request, "hackerthon.html")
    except Exception as e:
        return HttpResponse(f"Hackathon page error: {e}", status=500)


# ========== FREE COURSES VIEW ==========
def free_courses_view(request):
    try:
        return render(request, "free_course.html")
    except Exception as e:
        return HttpResponse(f"Free courses error: {e}", status=500)


# ========== FREE COURSES — GENERIC COURSE LOADER ==========
def _serve_course_index(course_slug):
    """Serve free_course/<slug>/index.html"""
    path = os.path.join(BASE_DIR, "free_course", course_slug, "index.html")
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            html = f.read()
        response = HttpResponse(html, content_type="text/html; charset=utf-8")
        response["Cache-Control"] = "public, max-age=300"
        return response
    except Exception as e:
        return HttpResponse(f"Course '{course_slug}' error: {e}", status=500)


def free_course_detail_view(request, course_slug):
    """Serve free_course/<slug>/index.html for any course."""
    if not course_slug or not re.match(r"^[a-z0-9\-]+$", course_slug):
        return free_courses_view(request)

    response = _serve_course_index(course_slug)
    if response is not None:
        return response

    return free_courses_view(request)


# ========== SCANNER VIEW ==========
def scanner_view(request):
    try:
        return render(request, "scanner.html")
    except Exception as e:
        return HttpResponse(f"Scanner error: {e}", status=500)


# ========== AUTOQUIZ VIEW ==========
def autoquiz_view(request):
    path = os.path.join(BASE_DIR, "autoquiz.html")
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                html = f.read()
            return HttpResponse(html, content_type="text/html")
        except Exception as e:
            return HttpResponse(f"Error loading AutoQuiz: {e}", status=500)
    return HttpResponse("AutoQuiz page not found.", status=404)


# ============================================================
# STUDENT HUB AUTH & SOCIAL VIEWS
# ============================================================
def login_view(request):
    if request.method == "POST":
        identifier = request.POST.get("username", "").strip()
        password = request.POST.get("password", "")
        student = hub_db.authenticate_student(identifier, password)
        if student:
            request.session["username"] = student["username"]
            next_url = request.GET.get("next") or "/dashboard/"
            return redirect(next_url)
        return render(request, "login.html", {"error": "Invalid email/username or password."})
    return render(request, "login.html")

def signup_view(request):
    if request.method == "POST":
        username = request.POST.get("username", "").strip().lower()
        full_name = request.POST.get("full_name", "").strip()
        email = request.POST.get("email", "").strip().lower()
        password = request.POST.get("password", "")
        confirm = request.POST.get("confirm_password", "")
        university = request.POST.get("university", "").strip()
        course = request.POST.get("course", "").strip()
        subject_stream = request.POST.get("subject_stream", "cs").strip()

        if password != confirm:
            return render(request, "signup.html", {"error": "Passwords do not match."})

        student, err = hub_db.create_student(
            username=username,
            email=email,
            password=password,
            full_name=full_name,
            university=university,
            course=course,
            subject_stream=subject_stream
        )
        if err:
            return render(request, "signup.html", {"error": err})

        request.session["username"] = student["username"]
        return redirect("/dashboard/")
    return render(request, "signup.html")

def logout_view(request):
    request.session.flush()
    return redirect("/")

def dashboard_view(request):
    username = request.session.get("username")
    if not username:
        return redirect("/login/?next=/dashboard/")
    student = hub_db.get_student_by_username(username)
    if not student:
        request.session.flush()
        return redirect("/login/")

    upload_history = hub_db.get_student_upload_history(username)
    favorites = hub_db.get_student_favorites(username)
    study_stats = hub_db.get_student_study_stats(username)
    unlocked_tokens = hub_db.get_unlocked_tokens_for_streak(student.get("streak", 1))
    following = hub_db.get_following_list(username)

    return render(request, "dashboard.html", {
        "student": student,
        "upload_history": upload_history,
        "favorites": favorites,
        "study_stats": study_stats,
        "unlocked_tokens": unlocked_tokens,
        "following": following
    })

def profile_view(request, username=None):
    current_user = request.session.get("username", "")
    target_username = username or current_user
    if not target_username:
        return redirect("/login/")

    student = hub_db.get_student_by_username(target_username)
    if not student:
        return HttpResponse("Student profile not found", status=404)

    is_own = (current_user == student["username"])
    is_following = hub_db.is_following(current_user, student["username"]) if current_user else False
    uploads = hub_db.get_student_upload_history(student["username"])
    favorites = hub_db.get_student_favorites(student["username"])
    unlocked_tokens = hub_db.get_unlocked_tokens_for_streak(student.get("streak", 1))

    return render(request, "profile.html", {
        "student": student,
        "is_own_profile": is_own,
        "is_following": is_following,
        "uploads": uploads,
        "favorites": favorites,
        "unlocked_tokens": unlocked_tokens
    })

def community_view(request):
    query = request.GET.get("q", "").strip()
    students = hub_db.get_all_students(limit=100, search=query)
    current_user = request.session.get("username", "")
    for s in students:
        s["is_following"] = hub_db.is_following(current_user, s["username"]) if current_user else False

    return render(request, "community.html", {
        "students": students,
        "query": query
    })

def daily_quiz_view(request):
    username = request.session.get("username", "")
    student = hub_db.get_student_by_username(username) if username else None
    default_stream = student.get("subject_stream", "cs") if student else "cs"
    subject = request.GET.get("subject", default_stream)

    quiz_data = hub_db.get_daily_quiz_for_subject(subject, username=username)
    return render(request, "daily_quiz.html", {
        "quiz": quiz_data,
        "all_subjects": hub_db.QUIZ_SUBJECTS
    })

@csrf_exempt
def api_submit_quiz(request):
    if request.method != "POST":
        return JsonResponse({"success": False, "error": "Method not allowed"}, status=405)
    username = request.session.get("username", "")
    if not username:
        return JsonResponse({"success": False, "error": "Authentication required"}, status=401)

    try:
        data = json.loads(request.body)
        subject_key = data.get("subject_key", "cs")
        answers = data.get("answers", {})
        result = hub_db.submit_quiz_answers(username, subject_key, answers)
        return JsonResponse({"success": True, **result})
    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)}, status=500)

def leaderboard_view(request):
    filter_type = request.GET.get("filter", "all")
    leaders = hub_db.get_leaderboard(filter_type=filter_type, limit=50)
    return render(request, "leaderboard.html", {
        "leaders": leaders,
        "current_filter": filter_type
    })

@csrf_exempt
def api_toggle_follow(request):
    if request.method != "POST":
        return JsonResponse({"success": False, "error": "Method not allowed"}, status=405)
    current_user = request.session.get("username", "")
    if not current_user:
        return JsonResponse({"success": False, "error": "Please sign in to follow students."}, status=401)

    try:
        data = json.loads(request.body)
        target = data.get("target_username", "").strip()
        is_following, msg = hub_db.toggle_follow(current_user, target)
        count = hub_db.get_followers_count(target)
        return JsonResponse({
            "success": True,
            "is_following": is_following,
            "message": msg,
            "followers_count": count
        })
    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)}, status=500)

@csrf_exempt
def api_toggle_favorite(request):
    if request.method != "POST":
        return JsonResponse({"success": False, "error": "Method not allowed"}, status=405)
    current_user = request.session.get("username", "")
    if not current_user:
        return JsonResponse({"success": False, "error": "Please sign in to add favourites."}, status=401)

    try:
        data = json.loads(request.body)
        item_id = data.get("item_id", "")
        item_type = data.get("item_type", "note")
        title = data.get("title", "Document")
        subtitle = data.get("subtitle", "")
        university = data.get("university", "")
        url = data.get("url", "")

        is_fav, msg = hub_db.toggle_favorite(current_user, item_id, item_type, title, subtitle, university, url)
        return JsonResponse({
            "success": True,
            "is_favorite": is_fav,
            "message": msg
        })
    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)}, status=500)

@csrf_exempt
def api_equip_token(request):
    if request.method != "POST":
        return JsonResponse({"success": False, "error": "Method not allowed"}, status=405)
    current_user = request.session.get("username", "")
    if not current_user:
        return JsonResponse({"success": False, "error": "Please sign in to equip badges."}, status=401)

    try:
        data = json.loads(request.body)
        token_id = data.get("token_id", "").strip()
        success, msg = hub_db.equip_token(current_user, token_id)
        return JsonResponse({"success": success, "message": msg})
    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)}, status=500)

@csrf_exempt
def api_log_study(request):
    if request.method != "POST":
        return JsonResponse({"success": False, "error": "Method not allowed"}, status=405)
    current_user = request.session.get("username", "")
    if not current_user:
        return JsonResponse({"success": False, "error": "Please sign in to log study progress."}, status=401)

    try:
        data = json.loads(request.body)
        minutes = int(data.get("minutes", 25))
        topics = int(data.get("topics", 1))
        note_id = data.get("note_id")
        hub_db.log_study_progress(current_user, minutes=minutes, topics=topics, note_id=note_id)
        return JsonResponse({"success": True})
    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)}, status=500)

def delete_own_file(request, id):
    current_user = request.session.get("username", "")
    if not current_user:
        return redirect("/login/")
    hub_db.delete_upload_history_item(id, current_user)
    return redirect("/dashboard/")


# ============================================================
# URLS
# ============================================================
urlpatterns = [
    path("", index),

    # 🔐 AUTH & STUDENT ACCOUNT ROUTES
    path("login/", login_view, name="login"),
    path("signup/", signup_view, name="signup"),
    path("logout/", logout_view, name="logout"),
    path("dashboard/", dashboard_view, name="dashboard"),
    path("profile/<str:username>/", profile_view, name="profile_user"),
    path("profile/", profile_view, name="profile_self"),
    path("community/", community_view, name="community"),
    path("daily-quiz/", daily_quiz_view, name="daily_quiz"),
    path("api/daily-quiz/submit/", api_submit_quiz, name="api_submit_quiz"),
    path("leaderboard/", leaderboard_view, name="leaderboard"),
    path("api/follow/toggle/", api_toggle_follow, name="api_toggle_follow"),
    path("api/favorite/toggle/", api_toggle_favorite, name="api_toggle_favorite"),
    path("api/favorites/toggle/", api_toggle_favorite, name="api_favorites_toggle"),
    path("api/tokens/equip/", api_equip_token, name="api_equip_token"),
    path("api/study/log/", api_log_study, name="api_log_study"),
    path("delete-own/<int:id>/", delete_own_file, name="delete_own_file"),

    # 🔐 SECRET ADMIN ROUTES
    path(f"{SECRET_ADMIN_PATH}/", admin_dashboard, name="admin_dashboard"),
    path(f"{SECRET_ADMIN_PATH}/settings/", admin_settings, name="admin_settings"),
    path("admin_edit/<int:id>/", admin_edit, name="admin_edit"),

    # ========== ICON / FAVICON / ROOT FILES ==========
    path("apple-touch-icon.png", serve_root_file, {"filename": "apple-touch-icon.png"}, name="apple_icon"),
    path("apple-touch-icon-precomposed.png", serve_root_file, {"filename": "apple-touch-icon.png"}),
    path("favicon.ico", favicon_view, name="favicon"),
    path("favicon.png", favicon_view, name="favicon_png"),

    # ========== MAIN PAGES ==========
    path("upload/", upload_view),
    path("browse/", browse_view),
    path("view/<int:id>/", view_file),
    path("download/<int:id>/", download_file),
    path("delete/<int:id>/", delete_file),
    path("update-passcode/<int:id>/", update_passcode, name="update_passcode"),
    path("update-metadata/<int:id>/", update_metadata, name="update_metadata"),


    # ABOUT PAGE
    path("about.html", about_view, name="about"),
    path("about/", about_view, name="about_alt"),

    # Calculator
    path("calculator.html", calculator_view),
    path("calculator/", calculator_view, name="calculator"),

    # HACKERTHON
    path("hackerthon.html", hackathon_view),
    path("hackerthon/", hackathon_view, name="hackerthon"),
    path("hackathon.html", hackathon_view),
    path("hackathon/", hackathon_view, name="hackathon"),

    # ============================================================
    # FREE_COURSE — LANDING PAGE
    # ============================================================
    path("free_course.html", free_courses_view),
    path("free_course/", free_courses_view, name="free_course"),
    path("free_courses.html", free_courses_view),
    path("free-courses/", free_courses_view, name="free_courses"),

    # ============================================================
    # FREE_COURSE — COURSE INDEX (specific courses)
    # Works for: github, web-hosting, python, html-css, english, kiswahili
    # ============================================================
    path("free_course/<slug:course_slug>/", free_course_detail_view, name="free_course_detail"),
    path("free_course/<slug:course_slug>/index.html", free_course_detail_view, name="free_course_detail_index"),

    # ============================================================
    # FREE_COURSE — ASSET SERVER (CSS, JS, images)
    # ============================================================
    path("free_course/<path:subpath>", serve_subfolder_file, name="free_course_assets"),

    # AUTOQUIZ
    path("autoquiz.html", autoquiz_view, name="autoquiz"),
    path("autoquiz/", autoquiz_view, name="autoquiz_alt"),

    # SCANNER ROUTE
    path("scanner.html", scanner_view, name="scanner"),
    path("scanner/", scanner_view, name="scanner_alt"),

    # STATIC ASSETS (hub-theme.css, hub.js, etc.)
    path("static/<path:subpath>", serve_static_file, name="static_files"),

    # ========== GENERIC ROOT FILE SERVER (must be LAST) ==========
    path("<str:filename>", serve_root_file, name="root_file"),
]

application = get_wsgi_application()
app = application

if __name__ == "__main__":
    from django.core.management import execute_from_command_line
    port = os.environ.get("PORT", 8000)
    execute_from_command_line([__name__, "runserver", f"0.0.0.0:{port}"])
