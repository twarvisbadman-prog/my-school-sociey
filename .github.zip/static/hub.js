/**
 * Student Hub - Interactive Features JS
 * Manages Favourites, Social Follows, Token Equipping,
 * Study Progress Logging, and Login Suggestion Modal.
 */

// Universal Toast Notification
function showToast(message, icon = '✨') {
    let toast = document.getElementById('hubGlobalToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'hubGlobalToast';
        toast.className = 'hub-toast';
        document.body.appendChild(toast);
    }
    toast.innerHTML = `<span style="font-size:1.1rem;">${icon}</span> <span>${message}</span>`;
    toast.classList.add('show');
    clearTimeout(window.__hubToastTimer);
    window.__hubToastTimer = setTimeout(() => {
        toast.classList.remove('show');
    }, 3200);
}

// Prompt Login Modal if Guest tries an account action
function promptLoginSuggestion(actionTitle = 'sign in') {
    let modal = document.getElementById('loginSuggestionModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'loginSuggestionModal';
        modal.style.cssText = `
            position: fixed; inset: 0; background: rgba(28,25,23,0.7);
            backdrop-filter: blur(8px); z-index: 99999; display: flex;
            align-items: center; justify-content: center; padding: 20px;
        `;
        modal.innerHTML = `
            <div style="background:#fff; border-radius:24px; max-width:440px; width:100%; padding:36px 30px; text-align:center; box-shadow:0 24px 60px rgba(0,0,0,0.3); position:relative; animation: popIn 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);">
                <button onclick="document.getElementById('loginSuggestionModal').remove()" style="position:absolute; top:16px; right:16px; background:#f5f5f4; border:none; width:34px; height:34px; border-radius:50%; font-size:1rem; cursor:pointer; color:#78716c;">✕</button>
                <div style="width:68px; height:68px; border-radius:50%; background:#fff7ed; color:#ea580c; font-size:2rem; display:inline-flex; align-items:center; justify-content:center; margin-bottom:16px; box-shadow:0 8px 20px rgba(234,88,12,0.2);">
                    🔥
                </div>
                <h2 style="font-size:1.45rem; font-weight:800; color:#1c1917; margin-bottom:8px;">Join the Student Hub</h2>
                <p id="loginPromptSubtitle" style="font-size:0.88rem; color:#57534e; line-height:1.5; margin-bottom:22px;">
                    Sign in to track your personal study progress, keep your daily streak alive, collect rare animal & player tokens, and follow classmates!
                </p>
                <div style="display:flex; flex-direction:column; gap:10px;">
                    <a href="/login/" style="display:block; padding:13px; background:linear-gradient(135deg,#ea580c,#db2777); color:#fff; font-weight:700; border-radius:12px; text-decoration:none; font-size:0.95rem; box-shadow:0 6px 18px rgba(234,88,12,0.4);">
                        Sign In to Your Account
                    </a>
                    <a href="/signup/" style="display:block; padding:12px; background:#f5f5f4; color:#1c1917; font-weight:700; border-radius:12px; text-decoration:none; font-size:0.92rem; border:1px solid #e7e5e4;">
                        Create Free Student Account
                    </a>
                </div>
                <p style="margin-top:16px; font-size:0.75rem; color:#a8a29e;">No credit card required · Free for all students</p>
            </div>
        `;
        document.body.appendChild(modal);
    }
    const sub = document.getElementById('loginPromptSubtitle');
    if (sub) {
        sub.textContent = `Sign in to ${actionTitle}, maintain your daily streak 🔥, and unlock cool animal/player tokens for your student profile!`;
    }
}

// 1-Click Toggle Favourites
async function toggleFavorite(btn, itemId, itemType = 'note', title = 'Document', subtitle = '', university = '', url = '') {
    try {
        const res = await fetch('/api/favorite/toggle/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                item_id: String(itemId),
                item_type: itemType,
                title: title,
                subtitle: subtitle,
                university: university,
                url: url
            })
        });

        if (res.status === 401) {
            promptLoginSuggestion('save notes to your personal favourites');
            return;
        }

        const data = await res.json();
        if (data.success) {
            if (data.is_favorite) {
                btn.classList.add('active');
                btn.innerHTML = '<i class="fas fa-heart"></i>';
                showToast('Added to your favourites!', '❤️');
            } else {
                btn.classList.remove('active');
                btn.innerHTML = '<i class="far fa-heart"></i>';
                showToast('Removed from favourites.', '🤍');
            }
        }
    } catch (err) {
        console.error('Error toggling favorite:', err);
    }
}

// 1-Click Toggle Social Follow
async function toggleFollow(btn, targetUsername) {
    try {
        const res = await fetch('/api/follow/toggle/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ target_username: targetUsername })
        });

        if (res.status === 401) {
            promptLoginSuggestion(`follow @${targetUsername}`);
            return;
        }

        const data = await res.json();
        if (data.success) {
            if (data.is_following) {
                btn.className = 'btn-follow following';
                btn.innerHTML = '<i class="fas fa-check"></i> Following';
                showToast(`You are now following @${targetUsername}!`, '👥');
            } else {
                btn.className = 'btn-follow not-following';
                btn.innerHTML = '<i class="fas fa-user-plus"></i> Follow';
                showToast(`Unfollowed @${targetUsername}.`, '👤');
            }
            // Update counter if element exists
            const counter = document.getElementById(`followersCount_${targetUsername}`);
            if (counter && data.followers_count !== undefined) {
                counter.textContent = data.followers_count;
            }
        } else {
            showToast(data.message || 'Error following user', '⚠️');
        }
    } catch (err) {
        console.error('Error toggling follow:', err);
    }
}

// 1-Click Equip Animal or Player Token
async function equipToken(btn, tokenId) {
    try {
        const res = await fetch('/api/tokens/equip/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token_id: tokenId })
        });

        if (res.status === 401) {
            promptLoginSuggestion('equip tokens on your profile');
            return;
        }

        const data = await res.json();
        if (data.success) {
            showToast(data.message, '🌟');
            // Refresh token cards in vault
            document.querySelectorAll('.btn-equip-token').forEach(b => {
                b.className = 'btn-equip-token can-equip';
                b.textContent = 'Equip Token';
            });
            btn.className = 'btn-equip-token active';
            btn.textContent = '✓ Equipped';

            // Also reload page after 800ms if on profile/dashboard to show updated badge
            setTimeout(() => { window.location.reload(); }, 900);
        } else {
            showToast(data.message || 'Cannot equip token', '⚠️');
        }
    } catch (err) {
        console.error('Error equipping token:', err);
    }
}

// Log Study Progress / Mark note as studied
async function markAsStudied(btn, noteId, minutes = 25) {
    try {
        const res = await fetch('/api/study/log/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                minutes: minutes,
                topics: 1,
                note_id: noteId
            })
        });

        if (res.status === 401) {
            promptLoginSuggestion('track your study progress');
            return;
        }

        const data = await res.json();
        if (data.success) {
            btn.innerHTML = '<i class="fas fa-check-circle"></i> Studied Today';
            btn.disabled = true;
            btn.style.opacity = '0.7';
            showToast(`Logged ${minutes} mins to your study streak! 🔥`, '📚');
        }
    } catch (err) {
        console.error('Error logging study:', err);
    }
}

// Auto-display subtle floating login prompt for guests
document.addEventListener('DOMContentLoaded', () => {
    const isGuest = document.body.dataset.auth === 'false' || !document.querySelector('.user-auth-badge');
    const dismissed = sessionStorage.getItem('hubPromptDismissed');

    if (isGuest && !dismissed) {
        setTimeout(() => {
            // Check if floating prompt is already on page
            if (!document.querySelector('.floating-login-prompt')) {
                const prompt = document.createElement('div');
                prompt.className = 'floating-login-prompt';
                prompt.innerHTML = `
                    <div class="floating-login-header">
                        <span class="floating-login-title"><span class="flame-icon">🔥</span> Join Student Hub</span>
                        <button class="floating-login-close" onclick="this.closest('.floating-login-prompt').remove(); sessionStorage.setItem('hubPromptDismissed', '1');">✕</button>
                    </div>
                    <p class="floating-login-desc">
                        Get a personal student account to maintain streaks, unlock cool animal & player badges, and bookmark notes!
                    </p>
                    <div style="display:flex; gap:8px;">
                        <a href="/login/" class="btn-pill-login" style="flex:1; justify-content:center; padding:8px 12px;">Sign In</a>
                        <a href="/signup/" class="btn-pill-signup" style="background:#f5f5f4; color:#1c1917 !important; border:1px solid #e7e5e4; flex:1; text-align:center; padding:8px 12px;">Sign Up</a>
                    </div>
                `;
                document.body.appendChild(prompt);
            }
        }, 3500);
    }
});
