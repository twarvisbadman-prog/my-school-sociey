"""
hub_db.py - Student Hub Local Persistence & Social Engine
Handles student accounts, social follows, upload history, favourites,
study progress tracking, streaks, animal/player token unlocks,
daily subject quizzes, and campus ranks.
"""

import os
import sqlite3
import hashlib
import json
from datetime import datetime, date, timedelta

DB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
DB_PATH = os.path.join(DB_DIR, "student_hub.db")

# ============================================================
# TOKENS & BADGES CATALOG
# ============================================================
TOKENS_CATALOG = [
    # Animal Tokens
    {
        "id": "cyber_cheetah",
        "name": "Cyber Cheetah",
        "emoji": "🐆",
        "category": "Animal",
        "required_streak": 3,
        "rarity": "Rare",
        "title": "Sprint Starter",
        "description": "Lightning-fast study sprints. Never lags on deadlines.",
        "color": "#f59e0b",
        "gradient": "linear-gradient(135deg, #f59e0b, #d97706)",
        "badge_class": "badge-amber"
    },
    {
        "id": "frost_wolf",
        "name": "Frost Wolf",
        "emoji": "🐺",
        "category": "Animal",
        "required_streak": 7,
        "rarity": "Epic",
        "title": "Pack Leader",
        "description": "Fierce discipline and unbreakable 7-day study consistency.",
        "color": "#06b6d4",
        "gradient": "linear-gradient(135deg, #06b6d4, #2563eb)",
        "badge_class": "badge-cyan"
    },
    {
        "id": "golden_lion",
        "name": "Golden Apex Lion",
        "emoji": "🦁",
        "category": "Animal",
        "required_streak": 14,
        "rarity": "Legendary",
        "title": "Academic Apex Predator",
        "description": "King of the library. Roars with 2 full weeks of focus.",
        "color": "#eab308",
        "gradient": "linear-gradient(135deg, #eab308, #b45309)",
        "badge_class": "badge-gold"
    },
    {
        "id": "astral_eagle",
        "name": "Astral Falcon",
        "emoji": "🦅",
        "category": "Animal",
        "required_streak": 21,
        "rarity": "Legendary",
        "title": "Visionary High-Flyer",
        "description": "Sharp eagle eyes scanning past papers with surgical accuracy.",
        "color": "#8b5cf6",
        "gradient": "linear-gradient(135deg, #8b5cf6, #ec4899)",
        "badge_class": "badge-purple"
    },
    {
        "id": "cyber_dragon",
        "name": "Mystic Cyber Dragon",
        "emoji": "🐉",
        "category": "Animal",
        "required_streak": 30,
        "rarity": "Mythic",
        "title": "Mythic Grandmaster",
        "description": "Breathes fiery mastery through a full 30-day exam campaign.",
        "color": "#ef4444",
        "gradient": "linear-gradient(135deg, #ef4444, #f97316)",
        "badge_class": "badge-red"
    },
    {
        "id": "galactic_phoenix",
        "name": "Galactic Phoenix",
        "emoji": "⚡",
        "category": "Animal",
        "required_streak": 50,
        "rarity": "Divine",
        "title": "Immortal Scholar",
        "description": "Rises above any difficult exam. Reborn with eternal brilliance.",
        "color": "#ec4899",
        "gradient": "linear-gradient(135deg, #ec4899, #f43f5e)",
        "badge_class": "badge-pink"
    },
    # Player / Athlete Tokens
    {
        "id": "speed_runner",
        "name": "Speed Runner",
        "emoji": "⚡",
        "category": "Player",
        "required_streak": 3,
        "rarity": "Rare",
        "title": "Sprint Phenomenon",
        "description": "Quick-thinking problem solver who crosses the line first.",
        "color": "#3b82f6",
        "gradient": "linear-gradient(135deg, #3b82f6, #06b6d4)",
        "badge_class": "badge-blue"
    },
    {
        "id": "court_prodigy",
        "name": "Court Prodigy",
        "emoji": "🏀",
        "category": "Player",
        "required_streak": 7,
        "rarity": "Epic",
        "title": "All-Star Playmaker",
        "description": "Clutches difficult questions like a game-winning buzzer-beater.",
        "color": "#f97316",
        "gradient": "linear-gradient(135deg, #f97316, #ea580c)",
        "badge_class": "badge-orange"
    },
    {
        "id": "golden_striker",
        "name": "Golden Striker",
        "emoji": "⚽",
        "category": "Player",
        "required_streak": 14,
        "rarity": "Legendary",
        "title": "Top Scorer",
        "description": "Sinks every past paper question into the top corner.",
        "color": "#10b981",
        "gradient": "linear-gradient(135deg, #10b981, #059669)",
        "badge_class": "badge-green"
    },
    {
        "id": "velocity_ace",
        "name": "Velocity Ace",
        "emoji": "🏎️",
        "category": "Player",
        "required_streak": 21,
        "rarity": "Legendary",
        "title": "Pole Position Champion",
        "description": "Top gear momentum with zero distractions and pure speed.",
        "color": "#dc2626",
        "gradient": "linear-gradient(135deg, #dc2626, #b91c1c)",
        "badge_class": "badge-red"
    },
    {
        "id": "grandmaster",
        "name": "Grandmaster",
        "emoji": "♟️",
        "category": "Player",
        "required_streak": 30,
        "rarity": "Mythic",
        "title": "Strategic Mastermind",
        "description": "Anticipates complex coursework 10 moves ahead.",
        "color": "#6366f1",
        "gradient": "linear-gradient(135deg, #6366f1, #4f46e5)",
        "badge_class": "badge-indigo"
    },
    {
        "id": "world_mvp",
        "name": "World MVP",
        "emoji": "🏆",
        "category": "Player",
        "required_streak": 50,
        "rarity": "Divine",
        "title": "Hall of Fame Titan",
        "description": "The undisputed campus champion. Reached the peak of academia.",
        "color": "#f59e0b",
        "gradient": "linear-gradient(135deg, #f59e0b, #eab308)",
        "badge_class": "badge-gold"
    }
]

TOKEN_MAP = {t["id"]: t for t in TOKENS_CATALOG}

# ============================================================
# SUBJECT QUESTION BANK FOR DAILY QUIZ
# ============================================================
QUIZ_SUBJECTS = {
    "cs": {
        "name": "Computer Science & IT",
        "icon": "fa-laptop-code",
        "color": "#2563eb",
        "questions": [
            {
                "id": "cs_1",
                "question": "Which data structure uses LIFO (Last In, First Out) ordering?",
                "options": ["Queue", "Stack", "Binary Search Tree", "Array List"],
                "answer": 1,
                "explanation": "A Stack operates on the Last-In First-Out (LIFO) principle, where elements are pushed and popped from the same top end."
            },
            {
                "id": "cs_2",
                "question": "What is the average time complexity of searching in an optimized Hash Table?",
                "options": ["O(n)", "O(log n)", "O(1)", "O(n^2)"],
                "answer": 2,
                "explanation": "Hash tables offer O(1) constant time average complexity for insertions, lookups, and deletions."
            },
            {
                "id": "cs_3",
                "question": "Which HTTP status code signifies that a resource was successfully created on the server?",
                "options": ["200 OK", "201 Created", "204 No Content", "301 Moved Permanently"],
                "answer": 1,
                "explanation": "HTTP 201 Created is returned when a POST request successfully creates a new entity."
            },
            {
                "id": "cs_4",
                "question": "In relational databases, which SQL clause is used to filter groups created by GROUP BY?",
                "options": ["WHERE", "ORDER BY", "HAVING", "LIMIT"],
                "answer": 2,
                "explanation": "HAVING filters aggregated groups after GROUP BY, whereas WHERE filters individual rows before grouping."
            },
            {
                "id": "cs_5",
                "question": "What does DNS stand for in computer networking?",
                "options": ["Dynamic Network System", "Domain Name System", "Digital Node Service", "Data Network Standard"],
                "answer": 1,
                "explanation": "DNS stands for Domain Name System, translating human-friendly domain names to IP addresses."
            }
        ]
    },
    "med": {
        "name": "Medicine & Health Sciences",
        "icon": "fa-heart-pulse",
        "color": "#dc2626",
        "questions": [
            {
                "id": "med_1",
                "question": "Which chamber of the human heart pumps oxygenated blood to the systemic circulation via the aorta?",
                "options": ["Right Atrium", "Right Ventricle", "Left Atrium", "Left Ventricle"],
                "answer": 3,
                "explanation": "The Left Ventricle has the thickest myocardium and pumps oxygen-rich blood into the aorta."
            },
            {
                "id": "med_2",
                "question": "What is the primary physiological function of Erythrocytes (Red Blood Cells)?",
                "options": ["Blood Clotting", "Oxygen Transport via Hemoglobin", "Humoral Antibody Production", "Phagocytosis of Pathogens"],
                "answer": 1,
                "explanation": "Erythrocytes are loaded with hemoglobin to transport oxygen from the lungs to peripheral tissues."
            },
            {
                "id": "med_3",
                "question": "Which cranial nerve provides parasympathetic innervation to the thoracic and abdominal organs?",
                "options": ["Cranial Nerve V (Trigeminal)", "Cranial Nerve VII (Facial)", "Cranial Nerve X (Vagus)", "Cranial Nerve XII (Hypoglossal)"],
                "answer": 2,
                "explanation": "The Vagus nerve (CN X) is the primary parasympathetic conduit for thoracic and visceral organs."
            },
            {
                "id": "med_4",
                "question": "Which organelle is the site of adenosine triphosphate (ATP) synthesis via oxidative phosphorylation?",
                "options": ["Ribosome", "Endoplasmic Reticulum", "Mitochondria", "Golgi Apparatus"],
                "answer": 2,
                "explanation": "Mitochondria generate the vast majority of cellular ATP via cellular respiration."
            },
            {
                "id": "med_5",
                "question": "Normal resting adult blood pressure is classified as approximately:",
                "options": ["120/80 mmHg", "160/100 mmHg", "90/40 mmHg", "140/95 mmHg"],
                "answer": 0,
                "explanation": "Standard normotensive reading for adults is around 120 mmHg systolic over 80 mmHg diastolic."
            }
        ]
    },
    "biz": {
        "name": "Business, Finance & Economics",
        "icon": "fa-chart-line",
        "color": "#16a34a",
        "questions": [
            {
                "id": "biz_1",
                "question": "What is the foundational fundamental accounting equation?",
                "options": ["Assets = Liabilities + Equity", "Assets + Liabilities = Equity", "Revenue - Expenses = Assets", "Liabilities = Assets + Capital"],
                "answer": 0,
                "explanation": "The core balance sheet equation is Assets = Liabilities + Owner's Equity."
            },
            {
                "id": "biz_2",
                "question": "In economics, when supply is fixed and demand increases, what typically happens to market equilibrium price?",
                "options": ["Price Falls", "Price Increases", "Price Stays Constant", "Quantity Demanded Drops to Zero"],
                "answer": 1,
                "explanation": "Higher demand competing for scarce fixed supply drives the equilibrium clearing price upward."
            },
            {
                "id": "biz_3",
                "question": "What does ROI stand for in financial management?",
                "options": ["Rate of Interest", "Return on Investment", "Ratio of Income", "Reserve Operating Index"],
                "answer": 1,
                "explanation": "Return on Investment measures the net gain or loss generated relative to the capital invested."
            },
            {
                "id": "biz_4",
                "question": "Which market structure features a single seller with complete market pricing control?",
                "options": ["Monopoly", "Oligopoly", "Monopolistic Competition", "Perfect Competition"],
                "answer": 0,
                "explanation": "A pure Monopoly exists when one enterprise is the sole supplier of a good or service."
            },
            {
                "id": "biz_5",
                "question": "What financial statement details revenues and expenses over a specific accounting period?",
                "options": ["Balance Sheet", "Cash Flow Statement", "Income Statement (Profit & Loss)", "Statement of Retained Earnings"],
                "answer": 2,
                "explanation": "The Income Statement summarizes total revenues and incurred expenses to yield net profit or loss."
            }
        ]
    },
    "law": {
        "name": "Law & Legal Studies",
        "icon": "fa-scale-balanced",
        "color": "#9333ea",
        "questions": [
            {
                "id": "law_1",
                "question": "What is the doctrine of precedent known as in Common Law jurisdictions?",
                "options": ["Habeas Corpus", "Stare Decisis", "Mens Rea", "Actus Reus"],
                "answer": 1,
                "explanation": "Stare Decisis ('to stand by things decided') binds courts to adhere to earlier judicial precedents."
            },
            {
                "id": "law_2",
                "question": "What are the essential elements required to form a legally binding contract?",
                "options": ["Offer, Acceptance, Consideration & Intention to create legal relations", "Signature and Notarization only", "Written agreement and monetary payment only", "Oral promise and handshake"],
                "answer": 0,
                "explanation": "A valid contract requires a clear offer, unequivocal acceptance, mutual consideration, and legal intent."
            },
            {
                "id": "law_3",
                "question": "What legal principle states that an accused person is presumed innocent until proven guilty?",
                "options": ["Burden of Proof on Prosecution", "Presumption of Innocence", "Double Jeopardy", "Ex Post Facto"],
                "answer": 1,
                "explanation": "The Presumption of Innocence is a cardinal human rights principle in criminal jurisprudence."
            },
            {
                "id": "law_4",
                "question": "In tort law, what standard of conduct is used to assess actionable negligence?",
                "options": ["Strict perfection", "Reasonable person standard", "Personal intention only", "Government regulation only"],
                "answer": 1,
                "explanation": "Negligence evaluates whether the defendant behaved as a hypothetical 'reasonable person' would under similar circumstances."
            },
            {
                "id": "law_5",
                "question": "What writ commands a custodian to produce a detainee before a court to test lawful custody?",
                "options": ["Mandamus", "Certiorari", "Habeas Corpus", "Quo Warranto"],
                "answer": 2,
                "explanation": "Habeas corpus prevents arbitrary detention by requiring authorities to justify the legal basis for imprisonment."
            }
        ]
    },
    "eng": {
        "name": "Engineering & Mathematics",
        "icon": "fa-calculator",
        "color": "#ea580c",
        "questions": [
            {
                "id": "eng_1",
                "question": "According to Ohm's Law in electrical circuits, Voltage (V) equals:",
                "options": ["Current (I) / Resistance (R)", "Current (I) * Resistance (R)", "Power (P) * Current (I)", "Resistance (R) / Current (I)"],
                "answer": 1,
                "explanation": "Ohm's Law states V = I * R (Voltage equals Current multiplied by Resistance)."
            },
            {
                "id": "eng_2",
                "question": "What is the derivative of f(x) = x^3 with respect to x?",
                "options": ["3x^2", "x^2", "3x", "6x"],
                "answer": 0,
                "explanation": "By the power rule of calculus, d/dx(x^n) = n * x^(n-1). Thus d/dx(x^3) = 3x^2."
            },
            {
                "id": "eng_3",
                "question": "Which law states that energy can neither be created nor destroyed, only transformed?",
                "options": ["Second Law of Thermodynamics", "First Law of Thermodynamics (Conservation of Energy)", "Newton's Third Law", "Hooke's Law"],
                "answer": 1,
                "explanation": "The First Law of Thermodynamics establishes the principle of conservation of energy."
            },
            {
                "id": "eng_4",
                "question": "What mechanical stress type occurs when equal and opposite forces pull outward on a member?",
                "options": ["Compression", "Tension", "Shear", "Torsion"],
                "answer": 1,
                "explanation": "Tensile stress stretches and elongates a material under pulling forces."
            },
            {
                "id": "eng_5",
                "question": "What is the value of the mathematical constant pi (π) approximated to 4 decimal places?",
                "options": ["3.1416", "3.1428", "3.1402", "3.1499"],
                "answer": 0,
                "explanation": "π ≈ 3.14159265... which rounds to 3.1416 at 4 decimal places."
            }
        ]
    },
    "agri": {
        "name": "Agriculture & Biological Sciences",
        "icon": "fa-seedling",
        "color": "#059669",
        "questions": [
            {
                "id": "agri_1",
                "question": "Which primary plant pigment is responsible for absorbing sunlight during photosynthesis?",
                "options": ["Carotenoid", "Chlorophyll", "Anthocyanin", "Hemoglobin"],
                "answer": 1,
                "explanation": "Chlorophyll in chloroplasts absorbs blue and red wavelengths to drive photosystems I and II."
            },
            {
                "id": "agri_2",
                "question": "What are the three essential primary macronutrients (NPK) found in commercial agricultural fertilizers?",
                "options": ["Nitrogen, Phosphorus, Potassium", "Nickel, Platinum, Potassium", "Nitrogen, Protein, Calcium", "Sodium, Phosphorus, Iron"],
                "answer": 0,
                "explanation": "NPK stands for Nitrogen (N), Phosphorus (P), and Potassium (K)."
            },
            {
                "id": "agri_3",
                "question": "Which soil particle has the smallest particle diameter and highest water retention capacity?",
                "options": ["Sand", "Silt", "Clay", "Gravel"],
                "answer": 2,
                "explanation": "Clay particles are less than 0.002 mm, providing massive surface area and water holding capacity."
            },
            {
                "id": "agri_4",
                "question": "Leguminous crops enrich soil fertility due to symbiotic root nodules containing which nitrogen-fixing bacteria?",
                "options": ["Rhizobium", "Escherichia coli", "Streptococcus", "Lactobacillus"],
                "answer": 0,
                "explanation": "Rhizobium species convert atmospheric N2 into bioavailable ammonia for the host plant and soil."
            },
            {
                "id": "agri_5",
                "question": "What is the process of water movement through a plant and its evaporation from aerial parts called?",
                "options": ["Transpiration", "Respiration", "Germination", "Pollination"],
                "answer": 0,
                "explanation": "Transpiration pulls water upward from roots through xylem conduits to evaporate via stomata."
            }
        ]
    }
}

# ============================================================
# DATABASE INITIALIZATION
# ============================================================
def get_db():
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()

    # Students / Users table
    c.execute("""
    CREATE TABLE IF NOT EXISTS students (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        university TEXT DEFAULT 'University of Dar es Salaam (UDSM)',
        course TEXT DEFAULT 'Computer Science',
        subject_stream TEXT DEFAULT 'cs',
        bio TEXT DEFAULT 'Eager learner striving for academic excellence!',
        avatar TEXT DEFAULT '👨‍🎓',
        streak INTEGER DEFAULT 1,
        last_active_date TEXT,
        equipped_token TEXT DEFAULT 'cyber_cheetah',
        xp INTEGER DEFAULT 120,
        study_minutes INTEGER DEFAULT 45,
        created_at TEXT NOT NULL
    )
    """)

    # Follows table (Student A follows Student B)
    c.execute("""
    CREATE TABLE IF NOT EXISTS follows (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        follower_username TEXT NOT NULL,
        following_username TEXT NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(follower_username, following_username)
    )
    """)

    # Upload History table
    c.execute("""
    CREATE TABLE IF NOT EXISTS upload_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        file_id INTEGER,
        filename TEXT NOT NULL,
        original_filename TEXT NOT NULL,
        module TEXT NOT NULL,
        course TEXT NOT NULL,
        university TEXT NOT NULL,
        file_type TEXT DEFAULT 'notes',
        privacy TEXT DEFAULT 'public',
        passcode TEXT DEFAULT '',
        file_size INTEGER DEFAULT 0,
        uploaded_at TEXT NOT NULL
    )
    """)

    # Favourites / Bookmarks table
    c.execute("""
    CREATE TABLE IF NOT EXISTS favorites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        item_id TEXT NOT NULL,
        item_type TEXT DEFAULT 'note',
        title TEXT NOT NULL,
        subtitle TEXT DEFAULT '',
        university TEXT DEFAULT '',
        url TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        UNIQUE(username, item_id, item_type)
    )
    """)

    # Study Sessions / Progress table
    c.execute("""
    CREATE TABLE IF NOT EXISTS study_progress (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        date TEXT NOT NULL,
        minutes_spent INTEGER DEFAULT 0,
        topics_completed INTEGER DEFAULT 0,
        daily_goal_topics INTEGER DEFAULT 3,
        notes_studied TEXT DEFAULT '[]',
        updated_at TEXT NOT NULL,
        UNIQUE(username, date)
    )
    """)

    # Daily Quiz Attempts
    c.execute("""
    CREATE TABLE IF NOT EXISTS quiz_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        subject TEXT NOT NULL,
        score INTEGER NOT NULL,
        total INTEGER NOT NULL,
        date TEXT NOT NULL,
        created_at TEXT NOT NULL
    )
    """)

    conn.commit()
    conn.close()

    # Seed community if empty
    seed_community_data()

# ============================================================
# PASSWORD HASHING
# ============================================================
def hash_password(password: str) -> str:
    salt = "twarvis_student_hub_salt_2026"
    return hashlib.sha256((salt + password).encode('utf-8')).hexdigest()

def verify_password(password: str, hashed: str) -> bool:
    return hash_password(password) == hashed

# ============================================================
# STUDENT AUTH & MANAGEMENT
# ============================================================
def create_student(username, email, password, full_name, university="", course="", subject_stream="cs"):
    conn = get_db()
    c = conn.cursor()
    username = username.strip().lower()
    email = email.strip().lower()

    # Check existing
    c.execute("SELECT id FROM students WHERE username = ? OR email = ?", (username, email))
    if c.fetchone():
        conn.close()
        return None, "Username or email is already registered."

    today = date.today().isoformat()
    student_id = f"std_{hashlib.md5(username.encode()).hexdigest()[:8]}"
    pwd_hash = hash_password(password)

    c.execute("""
    INSERT INTO students (
        id, username, email, password_hash, full_name, university, course,
        subject_stream, bio, avatar, streak, last_active_date,
        equipped_token, xp, study_minutes, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        student_id, username, email, pwd_hash, full_name,
        university or "University of Dar es Salaam (UDSM)",
        course or "Computer Science",
        subject_stream or "cs",
        "Eager learner striving for academic excellence!",
        "👨‍🎓",
        1,
        today,
        "cyber_cheetah",
        150,
        30,
        datetime.now().isoformat()
    ))
    conn.commit()
    conn.close()

    # Log initial study session
    log_study_progress(username, minutes=30, topics=1)
    return get_student_by_username(username), None

def authenticate_student(identifier, password):
    conn = get_db()
    c = conn.cursor()
    ident = identifier.strip().lower()
    c.execute("SELECT * FROM students WHERE username = ? OR email = ?", (ident, ident))
    row = c.fetchone()
    conn.close()
    if not row:
        return None
    if verify_password(password, row["password_hash"]):
        # Update streak check on login
        check_and_update_streak(row["username"])
        return get_student_by_username(row["username"])
    return None

def get_student_by_username(username):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM students WHERE username = ?", (username.strip().lower(),))
    row = c.fetchone()
    conn.close()
    if not row:
        return None
    data = dict(row)
    # Attach token details
    eq_token = TOKEN_MAP.get(data.get("equipped_token", "cyber_cheetah"), TOKENS_CATALOG[0])
    data["token_details"] = eq_token
    data["unlocked_tokens"] = get_unlocked_tokens_for_streak(data.get("streak", 1))
    data["followers_count"] = get_followers_count(data["username"])
    data["following_count"] = get_following_count(data["username"])
    return data

def update_student_profile(username, full_name=None, university=None, course=None, bio=None, avatar=None, subject_stream=None):
    conn = get_db()
    c = conn.cursor()
    updates = []
    params = []
    if full_name:
        updates.append("full_name = ?")
        params.append(full_name.strip())
    if university:
        updates.append("university = ?")
        params.append(university.strip())
    if course:
        updates.append("course = ?")
        params.append(course.strip())
    if bio:
        updates.append("bio = ?")
        params.append(bio.strip())
    if avatar:
        updates.append("avatar = ?")
        params.append(avatar.strip())
    if subject_stream:
        updates.append("subject_stream = ?")
        params.append(subject_stream.strip())

    if updates:
        params.append(username.strip().lower())
        c.execute(f"UPDATE students SET {', '.join(updates)} WHERE username = ?", params)
        conn.commit()
    conn.close()
    return get_student_by_username(username)

# ============================================================
# STREAK & TOKEN UNLOCKS
# ============================================================
def check_and_update_streak(username, bump=False):
    """
    Checks student's streak against calendar date.
    If last_active_date was yesterday and bump=True: streak += 1.
    If last_active_date was today: streak unchanged.
    If missed > 1 day: streak resets to 1 (or maintains if today).
    """
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT streak, last_active_date, xp, equipped_token FROM students WHERE username = ?", (username.strip().lower(),))
    row = c.fetchone()
    if not row:
        conn.close()
        return 1

    current_streak = row["streak"] or 1
    last_date_str = row["last_active_date"]
    xp = row["xp"] or 0
    today = date.today()
    today_str = today.isoformat()
    yesterday = today - timedelta(days=1)
    yesterday_str = yesterday.isoformat()

    new_streak = current_streak
    new_xp = xp

    if last_date_str == today_str:
        # Already active today
        if bump:
            new_xp += 25
    elif last_date_str == yesterday_str:
        # Consecutive day!
        if bump:
            new_streak += 1
            new_xp += 100
        else:
            # Maintained
            new_streak = current_streak
    elif not last_date_str:
        new_streak = 1
        new_xp += 50
    else:
        # Missed more than 1 day
        if bump:
            new_streak = 1
            new_xp += 50
        else:
            # Let's give grace: keep streak if active today
            new_streak = max(1, current_streak)

    c.execute("""
    UPDATE students SET streak = ?, last_active_date = ?, xp = ? WHERE username = ?
    """, (new_streak, today_str, new_xp, username.strip().lower()))
    conn.commit()
    conn.close()
    return new_streak

def get_unlocked_tokens_for_streak(streak):
    unlocked = []
    for token in TOKENS_CATALOG:
        is_unlocked = streak >= token["required_streak"]
        t = dict(token)
        t["unlocked"] = is_unlocked
        t["progress_percent"] = min(100, int((streak / token["required_streak"]) * 100))
        unlocked.append(t)
    return unlocked

def equip_token(username, token_id):
    if token_id not in TOKEN_MAP:
        return False, "Invalid token ID"
    student = get_student_by_username(username)
    if not student:
        return False, "Student not found"
    req_streak = TOKEN_MAP[token_id]["required_streak"]
    if student.get("streak", 1) < req_streak:
        return False, f"Streak requirement not met! You need a {req_streak}-day streak to equip {TOKEN_MAP[token_id]['name']}."

    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE students SET equipped_token = ? WHERE username = ?", (token_id, username.strip().lower()))
    conn.commit()
    conn.close()
    return True, f"Successfully equipped {TOKEN_MAP[token_id]['name']}!"

# ============================================================
# SOCIAL: FOLLOW / UNFOLLOW SYSTEM
# ============================================================
def toggle_follow(follower_username, target_username):
    follower = follower_username.strip().lower()
    target = target_username.strip().lower()
    if follower == target:
        return False, "You cannot follow yourself."

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id FROM follows WHERE follower_username = ? AND following_username = ?", (follower, target))
    existing = c.fetchone()

    if existing:
        c.execute("DELETE FROM follows WHERE follower_username = ? AND following_username = ?", (follower, target))
        is_following = False
        msg = f"Unfollowed {target}."
    else:
        c.execute("INSERT INTO follows (follower_username, following_username, created_at) VALUES (?, ?, ?)",
                  (follower, target, datetime.now().isoformat()))
        is_following = True
        msg = f"You are now following {target}!"

    conn.commit()
    conn.close()
    return is_following, msg

def is_following(follower_username, target_username):
    if not follower_username:
        return False
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id FROM follows WHERE follower_username = ? AND following_username = ?",
              (follower_username.strip().lower(), target_username.strip().lower()))
    res = bool(c.fetchone())
    conn.close()
    return res

def get_followers_count(username):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM follows WHERE following_username = ?", (username.strip().lower(),))
    count = c.fetchone()[0]
    conn.close()
    return count

def get_following_count(username):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM follows WHERE follower_username = ?", (username.strip().lower(),))
    count = c.fetchone()[0]
    conn.close()
    return count

def get_following_list(username):
    conn = get_db()
    c = conn.cursor()
    c.execute("""
    SELECT s.* FROM students s
    JOIN follows f ON f.following_username = s.username
    WHERE f.follower_username = ?
    ORDER BY s.streak DESC
    """, (username.strip().lower(),))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    for r in rows:
        r["token_details"] = TOKEN_MAP.get(r.get("equipped_token", "cyber_cheetah"), TOKENS_CATALOG[0])
    return rows

def get_all_students(limit=100, search=""):
    conn = get_db()
    c = conn.cursor()
    if search:
        q = f"%{search.strip().lower()}%"
        c.execute("""
        SELECT * FROM students
        WHERE username LIKE ? OR full_name LIKE ? OR university LIKE ? OR course LIKE ?
        ORDER BY streak DESC, xp DESC
        LIMIT ?
        """, (q, q, q, q, limit))
    else:
        c.execute("SELECT * FROM students ORDER BY streak DESC, xp DESC LIMIT ?", (limit,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    for r in rows:
        r["token_details"] = TOKEN_MAP.get(r.get("equipped_token", "cyber_cheetah"), TOKENS_CATALOG[0])
        r["followers_count"] = get_followers_count(r["username"])
    return rows

# ============================================================
# UPLOAD HISTORY
# ============================================================
def record_upload_history(username, filename, original_filename, module, course, university, file_size=0, privacy="public", passcode="", file_type="notes", file_id=None):
    conn = get_db()
    c = conn.cursor()
    c.execute("""
    INSERT INTO upload_history (
        username, file_id, filename, original_filename, module, course,
        university, file_type, privacy, passcode, file_size, uploaded_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        username.strip().lower(), file_id, filename, original_filename,
        module, course, university, file_type, privacy, passcode,
        file_size, datetime.now().isoformat()
    ))
    # Give XP for uploading notes
    c.execute("UPDATE students SET xp = xp + 150 WHERE username = ?", (username.strip().lower(),))
    conn.commit()
    conn.close()

    # Log study progress
    log_study_progress(username, minutes=20, topics=1)
    check_and_update_streak(username, bump=True)

def get_student_upload_history(username):
    conn = get_db()
    c = conn.cursor()
    c.execute("""
    SELECT * FROM upload_history WHERE username = ? ORDER BY uploaded_at DESC
    """, (username.strip().lower(),))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def delete_upload_history_item(item_id, username):
    conn = get_db()
    c = conn.cursor()
    c.execute("DELETE FROM upload_history WHERE id = ? AND username = ?", (item_id, username.strip().lower()))
    affected = c.rowcount
    conn.commit()
    conn.close()
    return affected > 0

# ============================================================
# FAVOURITES / BOOKMARKS
# ============================================================
def toggle_favorite(username, item_id, item_type="note", title="Untitled", subtitle="", university="", url=""):
    conn = get_db()
    c = conn.cursor()
    u = username.strip().lower()
    item_id_str = str(item_id)
    c.execute("SELECT id FROM favorites WHERE username = ? AND item_id = ? AND item_type = ?", (u, item_id_str, item_type))
    existing = c.fetchone()

    if existing:
        c.execute("DELETE FROM favorites WHERE username = ? AND item_id = ? AND item_type = ?", (u, item_id_str, item_type))
        is_fav = False
        msg = "Removed from favourites."
    else:
        c.execute("""
        INSERT INTO favorites (username, item_id, item_type, title, subtitle, university, url, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (u, item_id_str, item_type, title, subtitle, university, url, datetime.now().isoformat()))
        is_fav = True
        msg = "Added to favourites!"

    conn.commit()
    conn.close()
    return is_fav, msg

def is_favorite(username, item_id, item_type="note"):
    if not username:
        return False
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id FROM favorites WHERE username = ? AND item_id = ? AND item_type = ?",
              (username.strip().lower(), str(item_id), item_type))
    res = bool(c.fetchone())
    conn.close()
    return res

def get_student_favorites(username):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM favorites WHERE username = ? ORDER BY created_at DESC", (username.strip().lower(),))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

# ============================================================
# STUDY PROGRESS TRACKER
# ============================================================
def log_study_progress(username, minutes=25, topics=1, note_id=None):
    today = date.today().isoformat()
    conn = get_db()
    c = conn.cursor()
    u = username.strip().lower()

    c.execute("SELECT * FROM study_progress WHERE username = ? AND date = ?", (u, today))
    row = c.fetchone()

    if row:
        curr_mins = row["minutes_spent"] + minutes
        curr_topics = row["topics_completed"] + topics
        notes = json.loads(row["notes_studied"] or "[]")
        if note_id and str(note_id) not in notes:
            notes.append(str(note_id))
        c.execute("""
        UPDATE study_progress
        SET minutes_spent = ?, topics_completed = ?, notes_studied = ?, updated_at = ?
        WHERE id = ?
        """, (curr_mins, curr_topics, json.dumps(notes), datetime.now().isoformat(), row["id"]))
    else:
        notes = [str(note_id)] if note_id else []
        c.execute("""
        INSERT INTO study_progress (username, date, minutes_spent, topics_completed, daily_goal_topics, notes_studied, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (u, today, minutes, topics, 3, json.dumps(notes), datetime.now().isoformat()))

    # Update overall student minutes
    c.execute("UPDATE students SET study_minutes = study_minutes + ?, xp = xp + 30 WHERE username = ?", (minutes, u))
    conn.commit()
    conn.close()

    check_and_update_streak(username, bump=True)

def get_student_study_stats(username):
    today = date.today().isoformat()
    conn = get_db()
    c = conn.cursor()
    u = username.strip().lower()

    # Today's progress
    c.execute("SELECT * FROM study_progress WHERE username = ? AND date = ?", (u, today))
    today_row = c.fetchone()
    today_mins = today_row["minutes_spent"] if today_row else 0
    today_topics = today_row["topics_completed"] if today_row else 0
    daily_goal = today_row["daily_goal_topics"] if today_row else 3
    daily_percent = min(100, int((today_topics / max(1, daily_goal)) * 100))

    # Past 7 days
    c.execute("""
    SELECT date, minutes_spent, topics_completed FROM study_progress
    WHERE username = ? ORDER BY date DESC LIMIT 7
    """, (u,))
    recent_days = [dict(r) for r in c.fetchall()]

    # Total notes completed
    c.execute("SELECT SUM(topics_completed), SUM(minutes_spent) FROM study_progress WHERE username = ?", (u,))
    tot_row = c.fetchone()
    total_topics = tot_row[0] or 0
    total_minutes = tot_row[1] or 0

    conn.close()
    return {
        "today_minutes": today_mins,
        "today_topics": today_topics,
        "daily_goal": daily_goal,
        "daily_percent": daily_percent,
        "total_topics": total_topics,
        "total_minutes": total_minutes,
        "recent_days": recent_days
    }

# ============================================================
# DAILY QUIZ ENGINE
# ============================================================
def get_daily_quiz_for_subject(subject_key="cs", username=None):
    subj_data = QUIZ_SUBJECTS.get(subject_key, QUIZ_SUBJECTS["cs"])
    today = date.today().isoformat()

    has_completed_today = False
    today_score = None
    if username:
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT score, total FROM quiz_attempts WHERE username = ? AND subject = ? AND date = ?",
                  (username.strip().lower(), subject_key, today))
        row = c.fetchone()
        conn.close()
        if row:
            has_completed_today = True
            today_score = f"{row['score']}/{row['total']}"

    return {
        "subject_key": subject_key,
        "subject_name": subj_data["name"],
        "icon": subj_data["icon"],
        "color": subj_data["color"],
        "questions": subj_data["questions"],
        "has_completed_today": has_completed_today,
        "today_score": today_score,
        "today_date": today
    }

def submit_quiz_answers(username, subject_key, answers_dict):
    """
    answers_dict: { "cs_1": 1, "cs_2": 2, ... }
    """
    subj_data = QUIZ_SUBJECTS.get(subject_key, QUIZ_SUBJECTS["cs"])
    questions = subj_data["questions"]
    total = len(questions)
    score = 0
    results_detail = []

    for q in questions:
        q_id = q["id"]
        chosen = answers_dict.get(q_id)
        if chosen is not None:
            try:
                chosen = int(chosen)
            except:
                pass
        is_correct = chosen == q["answer"]
        if is_correct:
            score += 1
        results_detail.append({
            "id": q_id,
            "question": q["question"],
            "options": q["options"],
            "chosen": chosen,
            "correct": q["answer"],
            "is_correct": is_correct,
            "explanation": q["explanation"]
        })

    today = date.today().isoformat()
    conn = get_db()
    c = conn.cursor()
    u = username.strip().lower()

    # Record attempt
    c.execute("""
    INSERT INTO quiz_attempts (username, subject, score, total, date, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
    """, (u, subject_key, score, total, today, datetime.now().isoformat()))

    # Award XP: 50 XP per correct question + 50 bonus for completing quiz
    earned_xp = (score * 50) + 50
    c.execute("UPDATE students SET xp = xp + ? WHERE username = ?", (earned_xp, u))
    conn.commit()
    conn.close()

    # Maintain / Increase streak!
    new_streak = check_and_update_streak(username, bump=True)
    # Log 15 study minutes and 1 topic
    log_study_progress(username, minutes=15, topics=1)

    # Check newly unlocked tokens
    student = get_student_by_username(username)
    newly_unlocked = [t for t in TOKENS_CATALOG if t["required_streak"] == new_streak]

    return {
        "score": score,
        "total": total,
        "earned_xp": earned_xp,
        "new_streak": new_streak,
        "newly_unlocked": newly_unlocked,
        "results_detail": results_detail
    }

# ============================================================
# LEADERBOARD & RANKS
# ============================================================
def get_leaderboard(filter_type="all", limit=50):
    conn = get_db()
    c = conn.cursor()

    if filter_type == "streak":
        order_clause = "streak DESC, xp DESC"
    elif filter_type == "uploads":
        order_clause = "upload_count DESC, streak DESC"
    else:
        order_clause = "streak DESC, xp DESC, study_minutes DESC"

    c.execute(f"""
    SELECT s.*,
           (SELECT COUNT(*) FROM upload_history u WHERE u.username = s.username) as upload_count
    FROM students s
    ORDER BY {order_clause}
    LIMIT ?
    """, (limit,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()

    for idx, r in enumerate(rows, start=1):
        r["rank"] = idx
        r["token_details"] = TOKEN_MAP.get(r.get("equipped_token", "cyber_cheetah"), TOKENS_CATALOG[0])
        r["followers_count"] = get_followers_count(r["username"])
        if idx == 1:
            r["trophy"] = "🥇"
            r["rank_badge"] = "rank-gold"
        elif idx == 2:
            r["trophy"] = "🥈"
            r["rank_badge"] = "rank-silver"
        elif idx == 3:
            r["trophy"] = "🥉"
            r["rank_badge"] = "rank-bronze"
        else:
            r["trophy"] = f"#{idx}"
            r["rank_badge"] = "rank-default"

    return rows

# ============================================================
# SEED COMMUNITY DATA (REALISTIC CLASSMATES)
# ============================================================
def seed_community_data():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM students")
    count = c.fetchone()[0]

    if count >= 6:
        conn.close()
        return

    today = date.today().isoformat()
    mock_students = [
        {
            "username": "kelvin_tz",
            "email": "kelvin@studenthub.ac.tz",
            "full_name": "Kelvin Mwamba",
            "university": "University of Dar es Salaam (UDSM)",
            "course": "Computer Science & Software Eng",
            "subject_stream": "cs",
            "bio": "Coding algorithms and uploading past papers daily. Road to 30-day streak! 🚀",
            "avatar": "👨‍💻",
            "streak": 22,
            "equipped_token": "astral_eagle",
            "xp": 3450,
            "study_minutes": 820
        },
        {
            "username": "sarah_health",
            "email": "sarah.m@muhas.ac.tz",
            "full_name": "Sarah Lyimo",
            "university": "Muhimbili University of Health and Allied Sciences (MUHAS)",
            "course": "Doctor of Medicine (MD)",
            "subject_stream": "med",
            "bio": "Future Surgeon. Anatomy, Pathology & Clinical Rotations. Consistent beats genius.",
            "avatar": "👩‍⚕️",
            "streak": 16,
            "equipped_token": "golden_lion",
            "xp": 2890,
            "study_minutes": 710
        },
        {
            "username": "david_dit",
            "email": "david.k@dit.ac.tz",
            "full_name": "David Kimaro",
            "university": "Dar es Salaam Institute of Technology (DIT)",
            "course": "Electrical & Telecom Engineering",
            "subject_stream": "eng",
            "bio": "Circuits, signal processing, and robotics. Let's study smart together!",
            "avatar": "⚡",
            "streak": 12,
            "equipped_token": "golden_striker",
            "xp": 2150,
            "study_minutes": 590
        },
        {
            "username": "amina_sua",
            "email": "amina.b@sua.ac.tz",
            "full_name": "Amina Bakari",
            "university": "Sokoine University of Agriculture (SUA)",
            "course": "Agronomy & Soil Sciences",
            "subject_stream": "agri",
            "bio": "Sustainable farming and soil microbiology researcher. Passionate about green tech.",
            "avatar": "🌱",
            "streak": 9,
            "equipped_token": "frost_wolf",
            "xp": 1740,
            "study_minutes": 430
        },
        {
            "username": "brian_ifm",
            "email": "brian.j@ifm.ac.tz",
            "full_name": "Brian Josephat",
            "university": "Institute of Finance Management (IFM)",
            "course": "Banking, Finance & Economics",
            "subject_stream": "biz",
            "bio": "Analyzing market equities and financial statements. Aiming for Top 10 rank! 📈",
            "avatar": "📊",
            "streak": 7,
            "equipped_token": "court_prodigy",
            "xp": 1420,
            "study_minutes": 380
        },
        {
            "username": "fatma_udom",
            "email": "fatma.s@udom.ac.tz",
            "full_name": "Fatma Said",
            "university": "University of Dodoma (UDOM)",
            "course": "Bachelor of Laws (LL.B)",
            "subject_stream": "law",
            "bio": "Advocate in the making. Constitutional rights and international human rights law.",
            "avatar": "⚖️",
            "streak": 5,
            "equipped_token": "speed_runner",
            "xp": 1150,
            "study_minutes": 310
        }
    ]

    for s in mock_students:
        s_id = f"std_{hashlib.md5(s['username'].encode()).hexdigest()[:8]}"
        pwd_hash = hash_password("student123")
        c.execute("""
        INSERT OR IGNORE INTO students (
            id, username, email, password_hash, full_name, university, course,
            subject_stream, bio, avatar, streak, last_active_date,
            equipped_token, xp, study_minutes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            s_id, s["username"], s["email"], pwd_hash, s["full_name"],
            s["university"], s["course"], s["subject_stream"], s["bio"],
            s["avatar"], s["streak"], today, s["equipped_token"],
            s["xp"], s["study_minutes"], datetime.now().isoformat()
        ))

    # Cross-follow seed students to create real social network
    cross_follows = [
        ("kelvin_tz", "sarah_health"),
        ("kelvin_tz", "david_dit"),
        ("sarah_health", "kelvin_tz"),
        ("sarah_health", "amina_sua"),
        ("david_dit", "kelvin_tz"),
        ("david_dit", "brian_ifm"),
        ("amina_sua", "sarah_health"),
        ("brian_ifm", "fatma_udom"),
        ("fatma_udom", "kelvin_tz")
    ]
    for follower, following in cross_follows:
        c.execute("INSERT OR IGNORE INTO follows (follower_username, following_username, created_at) VALUES (?, ?, ?)",
                  (follower, following, datetime.now().isoformat()))

    conn.commit()
    conn.close()

# Initialize on module load
init_db()
